import os

# ---------------------------------------------------------------------------
# DEFAULT METADATA FIELDS
# These are read from QGIS layer properties and metadata object.
# They are the GIS-critical fields — tampering with any of these
# directly affects how the layer is interpreted and analyzed.
#
# Each entry is a dict with:
#   key         : internal identifier used in the database
#   label       : human-readable name shown in the UI
#   description : why this field matters for GIS analysis
# ---------------------------------------------------------------------------

DEFAULT_METADATA_FIELDS = [
    {
        "key": "crs",
        "label": "CRS / Projection",
        "description": "Coordinate Reference System. If changed, the entire layer is misplaced on earth."
    },
    {
        "key": "geometry_type",
        "label": "Geometry Type",
        "description": "Point, Line, or Polygon. Changing this breaks all spatial analysis."
    },
    {
        "key": "bbox",
        "label": "Bounding Box",
        "description": "Spatial extent of the layer. Tampering falsifies the coverage area."
    },
    {
        "key": "feature_count",
        "label": "Feature Count",
        "description": "Total number of features. If changed, deletion of data goes undetected."
    },
    {
        "key": "identifier",
        "label": "Identifier",
        "description": "Unique ID of the layer. If changed, the layer becomes untraceable."
    },
    {
        "key": "title",
        "label": "Title / Name",
        "description": "Official name of the dataset. Misrepresentation of what the layer contains."
    },
    {
        "key": "abstract",
        "label": "Abstract / Description",
        "description": "Description of the layer. Can be manipulated to misrepresent content."
    },
    {
        "key": "owner",
        "label": "Owner / Contacts",
        "description": "Responsible organization or person. Hiding accountability."
    },
    {
        "key": "source",
        "label": "Source / Keywords",
        "description": "Data origin. Hiding where data came from is a common fraud technique."
    },
    {
        "key": "lineage",
        "label": "Lineage / History",
        "description": "Processing history. Removing steps hides how data was manipulated."
    },
    {
        "key": "scale_denominator",
        "label": "Scale Denominator",
        "description": "Map scale. Affects accuracy of all distance and area measurements."
    },
    {
        "key": "spatial_resolution",
        "label": "Spatial Resolution",
        "description": "Resolution of source data. Inflating this misleads users about precision."
    },
    {
        "key": "accuracy",
        "label": "Accuracy / Constraints",
        "description": "Positional accuracy. Inflating this misleads downstream analysis."
    },
    {
        "key": "date_created",
        "label": "Date Created",
        "description": "When data was collected. Backdating hides when data was gathered.",
        "default_checked": True
    },
    {
        "key": "date_modified",
        "label": "Date Modified (excluded by default)",
        "description": "Last modification date. Excluded by default because QGIS updates this automatically on save — include only if you want strict change detection.",
        "default_checked": False
    },
]

# Just the keys — used for quick lookup
DEFAULT_FIELD_KEYS = [f["key"] for f in DEFAULT_METADATA_FIELDS]

# Plugin folder
PLUGIN_DIR = os.path.dirname(__file__)

# NOTE: The secret HMAC key is now stored INSIDE hashes.db
# The secret.key file is no longer used.
# Each hashes.db is self-contained with its own key.

# Local private database — stores tamper logs, never shared
LOCAL_DB_PATH = os.path.join(PLUGIN_DIR, "local_data.db")
