"""
hash_engine.py — PBKDF2 password-derived key upgrade
"""
import hashlib
import hmac as hmac_module
import os

PBKDF2_ITERATIONS = 310_000
PBKDF2_KEY_LEN    = 32

def generate_pbkdf2_salt():
    return os.urandom(32).hex()

def derive_key_from_password(password: str, salt_hex: str,
                              iterations: int = PBKDF2_ITERATIONS) -> str:
    """
    Derive a 256-bit HMAC key from password using PBKDF2-HMAC-SHA256.
    Same password + salt always produces the same key.
    Key is NEVER stored anywhere — re-derived on each use.
    """
    key_bytes = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        bytes.fromhex(salt_hex),
        iterations,
        dklen=PBKDF2_KEY_LEN
    )
    return key_bytes.hex()

def normalize_value(value):
    if value is None:
        return ""
    s = str(value).strip()
    if s in ("", "NULL", "None", "null", "none"):
        return ""
    s = s.replace("\r\n", " ").replace("\r", " ").replace("\n", " ")
    s = s.lower()
    s = " ".join(s.split())
    return s

def generate_salt():
    return os.urandom(16).hex()

def compute_hmac(text, salt, key_hex):
    key      = bytes.fromhex(key_hex)
    combined = (salt + text).encode("utf-8")
    return hmac_module.new(key, combined, hashlib.sha256).hexdigest()

def compute_all_hashes(metadata_dict, salt, key_hex):
    normalized_data = {}
    field_hashes    = {}
    for field_key in sorted(metadata_dict.keys()):
        normalized                 = normalize_value(metadata_dict[field_key])
        normalized_data[field_key] = normalized
        field_hashes[field_key]    = compute_hmac(normalized, salt, key_hex)
    joined        = "".join(field_hashes[k] for k in sorted(field_hashes.keys()))
    combined_hash = compute_hmac(joined, salt, key_hex)
    return {
        "field_hashes":    field_hashes,
        "combined_hash":   combined_hash,
        "normalized_data": normalized_data
    }
