"""
semantic_checker.py  — v2
=========================
Semantic / NLP-based Consistency Checker
CE432 Group 2 — Metadata Integrity Verifier

IMPROVEMENTS IN v2
------------------
R1–R3  : Synonym-aware, domain-expanded geometry vocabulary
R10    : Upgraded from raw Jaccard to TF-IDF weighted cosine similarity
R11    : NEW — Spatial extent vs CRS plausibility check
R12    : NEW — Feature count plausibility check
R13    : NEW — Duplicate / boilerplate / template detection
R14    : NEW — Attribute table field name vs abstract/keyword consistency
VERDICT: Three-tier output  CONSISTENT / WARN / SUSPICIOUS
         with per-rule contribution breakdown
"""

import re
from datetime import datetime
from collections import Counter
import math

# ---------------------------------------------------------------------------
# KNOWLEDGE BASE  (expanded vocabulary for R1-R3)
# ---------------------------------------------------------------------------

GEOM_KEYWORD_HINTS = {
    "POINT": [
        "point", "points", "place", "location", "site", "node",
        "airport", "city", "town", "label", "station", "sample",
        "observation", "incident", "occurrence", "landmark", "facility",
        "well", "borehole", "sensor", "camera", "monument", "marker",
    ],
    "MULTIPOINT": [
        "point", "points", "place", "location", "site", "station",
        "sample", "observation", "occurrence", "cluster",
    ],
    "LINESTRING": [
        "line", "river", "road", "route", "rail", "pipeline",
        "stream", "network", "centerline", "reef", "coast",
        "corridor", "alignment", "traverse", "transect", "reach",
        "channel", "path", "trail", "track", "cable", "wire",
        "transmission", "waterway", "drain", "sewer", "contour",
    ],
    "MULTILINESTRING": [
        "line", "river", "road", "route", "rail", "stream",
        "network", "coastline", "centerline", "reef", "coast",
        "corridor", "alignment", "transect", "reach", "channel",
        "path", "trail", "track", "cable", "waterway", "drain",
    ],
    "POLYGON": [
        "polygon", "area", "region", "boundary", "zone",
        "country", "lake", "ocean", "land", "island", "basin",
        "shelf", "glacier", "playa", "catchment", "watershed",
        "parcel", "footprint", "extent", "coverage", "jurisdiction",
        "delineation", "district", "block", "plot", "patch",
        "habitat", "reserve", "forest", "urban", "administrative",
    ],
    "MULTIPOLYGON": [
        "polygon", "area", "region", "boundary", "zone",
        "country", "lake", "ocean", "land", "island", "basin",
        "shelf", "glacier", "playa", "catchment", "watershed",
        "parcel", "footprint", "extent", "coverage", "jurisdiction",
        "district", "block", "plot", "patch", "habitat", "reserve",
        "forest", "urban", "administrative",
    ],
}

IDENTIFIER_GEOM_HINTS = {
    "point":      ["POINT", "MULTIPOINT"],
    "points":     ["POINT", "MULTIPOINT"],
    "station":    ["POINT", "MULTIPOINT"],
    "site":       ["POINT", "MULTIPOINT"],
    "location":   ["POINT", "MULTIPOINT"],
    "line":       ["LINESTRING", "MULTILINESTRING"],
    "lines":      ["LINESTRING", "MULTILINESTRING"],
    "centerline": ["LINESTRING", "MULTILINESTRING"],
    "coastline":  ["LINESTRING", "MULTILINESTRING"],
    "reef":       ["LINESTRING", "MULTILINESTRING"],
    "network":    ["LINESTRING", "MULTILINESTRING"],
    "route":      ["LINESTRING", "MULTILINESTRING"],
    "road":       ["LINESTRING", "MULTILINESTRING"],
    "river":      ["LINESTRING", "MULTILINESTRING"],
    "polygon":    ["POLYGON", "MULTIPOLYGON"],
    "polygons":   ["POLYGON", "MULTIPOLYGON"],
    "area":       ["POLYGON", "MULTIPOLYGON"],
    "region":     ["POLYGON", "MULTIPOLYGON"],
    "boundary":   ["POLYGON", "MULTIPOLYGON"],
    "zone":       ["POLYGON", "MULTIPOLYGON"],
    "catchment":  ["POLYGON", "MULTIPOLYGON"],
    "watershed":  ["POLYGON", "MULTIPOLYGON"],
    "parcel":     ["POLYGON", "MULTIPOLYGON"],
    "district":   ["POLYGON", "MULTIPOLYGON"],
}

GEOM_CONTRADICTIONS = {
    "MULTIPOLYGON":    ["line network", "linear feature", "linestring", "polyline", "centerline"],
    "POLYGON":         ["line network", "linear feature", "linestring", "polyline", "centerline"],
    "MULTILINESTRING": ["polygon boundary", "area coverage", "surface area", "land parcel"],
    "LINESTRING":      ["polygon boundary", "area coverage", "surface area", "land parcel"],
    "POINT":           ["polygon boundary", "area coverage", "linear network", "road network"],
    "MULTIPOINT":      ["polygon boundary", "area coverage", "linear network", "road network"],
}

GLOBAL_CRS = {"EPSG:4326", "EPSG:4269", "EPSG:4258", "CRS:84", "OGC:CRS84"}

# Approximate bounding boxes for common regions (minX, minY, maxX, maxY) in WGS84
REGION_BBOX = {
    "india":       (68.0,  6.0,  97.5, 36.0),
    "usa":         (-125.0, 24.0, -66.0, 50.0),
    "uk":          (-8.0,  49.5,   2.0, 61.0),
    "europe":      (-11.0, 34.0,  40.0, 72.0),
    "africa":      (-18.0, -35.0, 52.0, 38.0),
    "australia":   (113.0, -44.0, 154.0, -10.0),
    "china":       (73.0,  18.0, 135.0, 53.0),
    "brazil":      (-74.0, -34.0, -28.0,  5.0),
    "canada":      (-141.0, 41.7, -52.0, 83.0),
    "global":      (-180.0, -90.0, 180.0, 90.0),
    "world":       (-180.0, -90.0, 180.0, 90.0),
}

STOPWORDS = {
    "a","an","the","and","or","of","in","to","for","is","are","was","were",
    "it","its","this","that","with","as","at","by","from","on","be","been",
    "has","have","had","not","no","use","used","data","dataset","layer",
    "created","modified","may","can","will","should","all","any","each",
    "which","these","those","their","they","we","our","also","both","than",
    "more","other","such","only","into","over","after","been","about",
}

SUSPICIOUS_WORDS = [
    (r'\bhack\b',      0.95, "Contains word 'hack'"),
    (r'\battack\b',    0.90, "Contains word 'attack'"),
    (r'\bweapon\b',    0.95, "Contains word 'weapon'"),
    (r'\bmalware\b',   0.98, "Contains word 'malware'"),
    (r'\billegal\b',   0.75, "Contains word 'illegal'"),
    (r'\bfake\b',      0.70, "Contains word 'fake'"),
    (r'\bforged?\b',   0.80, "Contains word 'forge/forged'"),
    (r'\bcrack\b',     0.70, "Contains word 'crack'"),
    (r'\baltered\b',   0.65, "Contains word 'altered'"),
    (r'\btampered\b',  0.85, "Contains word 'tampered'"),
    (r'\bunauthorized\b', 0.70, "Contains word 'unauthorized'"),
    (r'(.)\1{6,}',     0.60, "Repeated character run (garbled text)"),
    (r'\b\w{30,}\b',   0.50, "Abnormally long word (possible injection)"),
]

BOILERPLATE_PHRASES = [
    "this dataset contains",
    "no warranty is expressed",
    "for more information contact",
    "data was collected by",
    "this layer contains",
    "this data contains",
]

RULE_WEIGHTS = {
    "R1":  0.10, "R2":  0.10, "R3":  0.07, "R4":  0.07,
    "R5":  0.12, "R6":  0.20, "R7":  0.14, "R8":  0.07,
    "R9":  0.05, "R10": 0.07, "R11": 0.05, "R12": 0.04,
    "R13": 0.03, "R14": 0.02,
}

# Three-tier verdict thresholds
THRESHOLD_WARN       = 0.10
THRESHOLD_SUSPICIOUS = 0.28

# ---------------------------------------------------------------------------
# METADATA EXTRACTION
# ---------------------------------------------------------------------------

def _extract_from_layer(layer):
    from qgis.core import QgsWkbTypes
    meta = layer.metadata()

    # Geometry type — normalised to base type
    geom_type = QgsWkbTypes.displayString(layer.wkbType()).upper()
    for base in ["MULTIPOLYGON", "MULTILINESTRING", "MULTIPOINT",
                 "POLYGON", "LINESTRING", "POINT"]:
        if geom_type.startswith(base):
            geom_type = base
            break

    # Keywords
    keywords = []
    for keyword_set in meta.keywords().values():
        for kw in keyword_set:
            if kw.strip():
                keywords.append(kw.strip().lower())

    # Contacts
    emails, orgs = [], []
    for contact in meta.contacts():
        if hasattr(contact, "email") and contact.email:
            emails.append(contact.email.strip().lower())
        if hasattr(contact, "organization") and contact.organization:
            orgs.append(contact.organization.strip())

    # Dates (guarded for older QGIS)
    dates = {}
    try:
        for date_obj in meta.dates():
            type_str  = str(date_obj.type)
            value_str = date_obj.date.toString("yyyy-MM-ddTHH:mm:ss")
            if "Created" in type_str or "created" in type_str:
                dates["Created"]   = value_str
            elif "Published" in type_str or "published" in type_str:
                dates["Published"] = value_str
    except AttributeError:
        pass

    # CRS
    authid = layer.crs().authid() if layer.crs().isValid() else ""

    # Spatial extent (actual layer bounding box in layer CRS)
    extent = layer.extent()
    spatial_extent = {
        "xmin": extent.xMinimum(),
        "ymin": extent.yMinimum(),
        "xmax": extent.xMaximum(),
        "ymax": extent.yMaximum(),
        "valid": not extent.isEmpty(),
    }

    # Feature count
    feature_count = layer.featureCount()

    # Attribute field names
    field_names = [f.name().lower() for f in layer.fields()]

    return {
        "geom_type":      geom_type,
        "identifier":     (meta.identifier() or "").strip(),
        "abstract":       (meta.abstract()   or "").strip(),
        "title":          (meta.title()      or "").strip(),
        "authid":         authid,
        "keywords":       keywords,
        "dates":          dates,
        "contact_emails": emails,
        "contact_orgs":   orgs,
        "spatial_extent": spatial_extent,
        "feature_count":  feature_count,
        "field_names":    field_names,
    }


# ---------------------------------------------------------------------------
# TEXT UTILITIES
# ---------------------------------------------------------------------------

def _tokenize(text):
    tokens = re.findall(r"[a-z]+", text.lower())
    return [t for t in tokens if t not in STOPWORDS and len(t) > 2]


def _tfidf_cosine(text_a, text_b):
    """
    TF-IDF weighted cosine similarity between two text strings.
    Uses both texts as the 'corpus' (2 docs) so IDF rewards rare shared terms.
    Returns float 0.0 – 1.0.
    """
    tokens_a = _tokenize(text_a)
    tokens_b = _tokenize(text_b)
    if not tokens_a or not tokens_b:
        return 0.0

    vocab    = set(tokens_a) | set(tokens_b)
    tf_a     = Counter(tokens_a)
    tf_b     = Counter(tokens_b)
    N        = 2  # two-document corpus

    def tfidf_vec(tf, tokens):
        vec = {}
        total = len(tokens)
        for term in vocab:
            tf_score  = tf[term] / total if total else 0
            doc_freq  = (1 if tf_a[term] > 0 else 0) + (1 if tf_b[term] > 0 else 0)
            idf_score = math.log((N + 1) / (doc_freq + 1)) + 1
            vec[term] = tf_score * idf_score
        return vec

    vec_a = tfidf_vec(tf_a, tokens_a)
    vec_b = tfidf_vec(tf_b, tokens_b)

    dot    = sum(vec_a[t] * vec_b[t] for t in vocab)
    norm_a = math.sqrt(sum(v ** 2 for v in vec_a.values()))
    norm_b = math.sqrt(sum(v ** 2 for v in vec_b.values()))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


# ---------------------------------------------------------------------------
# THE 14 RULES
# ---------------------------------------------------------------------------

def _r1_geom_keyword(m):
    geom  = m["geom_type"]
    kws   = " ".join(m["keywords"])
    hints = GEOM_KEYWORD_HINTS.get(geom, [])
    if not hints:
        return True, 0.0, "Unknown geometry type — skipped"
    matches = sum(1 for h in hints if h in kws)
    if matches >= 2:
        return True, 0.0, f"Keywords contain {matches} geometry-consistent hints ✓"
    if matches == 1:
        return True, 0.10, "Only 1 geometry hint in keywords — weak match"
    return False, 0.70, f"No {geom} hints found in keywords: {m['keywords'][:4]}"


def _r2_geom_identifier(m):
    geom   = m["geom_type"]
    ident  = m["identifier"].lower()
    tokens = re.findall(r"[a-z]+", ident)
    for tok in tokens:
        expected = IDENTIFIER_GEOM_HINTS.get(tok)
        if expected and geom not in expected:
            return False, 0.75, (
                f"Identifier token '{tok}' implies {expected} "
                f"but actual geometry is {geom}"
            )
    return True, 0.0, "Identifier consistent with geometry ✓"


def _r3_geom_abstract(m):
    geom     = m["geom_type"]
    abstract = m["abstract"].lower()
    if not abstract or not geom:
        return True, 0.0, "Skipped — empty abstract or unknown geometry"
    for c in GEOM_CONTRADICTIONS.get(geom, []):
        if c in abstract:
            return False, 0.70, (
                f"Abstract uses '{c}' which contradicts geometry type {geom}"
            )
    return True, 0.0, "No geometry contradiction found in abstract ✓"


def _r4_identifier_keywords(m):
    ident  = m["identifier"].lower()
    tokens = [t for t in re.findall(r"[a-z]+", ident)
              if t not in STOPWORDS and len(t) > 3
              and t not in {"10m", "50m", "110m", "ne", "adm", "admin"}]
    if not tokens:
        return True, 0.0, "No meaningful identifier tokens to check"
    kw_blob = " ".join(m["keywords"])
    matches = [t for t in tokens if t in kw_blob]
    ratio   = len(matches) / len(tokens)
    if ratio < 0.3:
        missing = list(set(tokens) - set(matches))[:4]
        return False, 0.60, (
            f"Only {len(matches)}/{len(tokens)} identifier tokens in keywords; "
            f"missing: {missing}"
        )
    return True, 0.0, f"{len(matches)}/{len(tokens)} identifier tokens present in keywords ✓"


def _r5_date_logic(m):
    dates     = m["dates"]
    created   = dates.get("Created",   "")
    published = dates.get("Published", "")
    if not created or not published:
        return True, 0.0, "One or both dates missing — skipped"
    try:
        dt_c = datetime.fromisoformat(created.replace("Z", ""))
        dt_p = datetime.fromisoformat(published.replace("Z", ""))
    except ValueError:
        return True, 0.0, "Could not parse dates — skipped"
    diff_hours = (dt_c - dt_p).total_seconds() / 3600
    if diff_hours > 25:
        return False, 0.85, (
            f"Created ({created}) is {diff_hours:.0f}h after Published ({published})"
        )
    return True, 0.0, "Date order valid (Created ≤ Published + 25h tolerance) ✓"


def _r6_crs_identifier(m):
    authid = m["authid"]
    ident  = m["identifier"].lower()
    global_hints = ["world", "global", "ocean", "ne_1", "ne_5", "ne_10", "ne_11"]
    is_global = any(h in ident for h in global_hints)
    if not is_global:
        return True, 0.0, "Not a clearly global dataset — CRS check skipped"
    if authid in GLOBAL_CRS:
        return True, 0.0, f"Global dataset uses geographic CRS {authid} ✓"
    if not authid:
        return False, 0.50, "Global dataset has no CRS declared"
    return False, 0.65, (
        f"Global dataset uses projected CRS '{authid}' — expected geographic CRS"
    )


def _r7_abstract_anomaly(m):
    abstract = m["abstract"]
    if not abstract:
        return True, 0.0, "Empty abstract — skipped"
    findings, max_conf = [], 0.0
    for pattern, conf, reason in SUSPICIOUS_WORDS:
        if re.search(pattern, abstract, re.IGNORECASE):
            findings.append(reason)
            max_conf = max(max_conf, conf)
    if findings:
        return False, max_conf, "Suspicious content in abstract: " + "; ".join(findings)
    if len(abstract) < 20:
        return False, 0.45, f"Abstract too short ({len(abstract)} chars) — suspicious"
    return True, 0.0, "Abstract passes anomaly scan ✓"


def _r8_email_domain(m):
    emails = m["contact_emails"]
    if len(emails) < 2:
        return True, 0.0, "Single or no contact email — skipped"
    domains = set()
    for e in emails:
        parts = e.split("@")
        if len(parts) == 2:
            domains.add(parts[1])
    if len(domains) > 1:
        return False, 0.65, f"Multiple email domains found: {sorted(domains)}"
    return True, 0.0, f"All emails share domain '{list(domains)[0]}' ✓"


def _r9_keyword_redundancy(m):
    kws = [k.strip() for k in m["keywords"] if k.strip()]
    if len(kws) < 3:
        return True, 0.0, "Too few keywords to assess redundancy"
    all_tokens = []
    for k in kws:
        all_tokens.extend(_tokenize(k))
    if not all_tokens:
        return True, 0.0, "No meaningful keyword tokens found"
    unique_ratio = len(set(all_tokens)) / len(all_tokens)
    if unique_ratio < 0.4:
        return False, 0.55, (
            f"High keyword redundancy: unique token ratio = {unique_ratio:.2f} "
            f"(threshold 0.40)"
        )
    if len(kws) > 20:
        return False, 0.50, f"Excessive keyword count ({len(kws)}) — possible stuffing"
    return True, 0.0, f"Keyword diversity OK: {unique_ratio:.2f} unique ratio ✓"


def _r10_abstract_keyword_coherence(m):
    """Upgraded: TF-IDF cosine similarity instead of raw Jaccard."""
    abstract = m["abstract"]
    kws      = m["keywords"]
    if not abstract or not kws:
        return True, 0.0, "Missing abstract or keywords — skipped"
    kw_text  = " ".join(kws)
    cosine   = _tfidf_cosine(abstract, kw_text)
    if cosine < 0.05 and len(abstract) > 80:
        return False, 0.60, (
            f"Very low abstract–keyword TF-IDF cosine ({cosine:.3f}) — "
            f"topics appear inconsistent"
        )
    return True, 0.0, f"Abstract–keyword coherence OK (TF-IDF cosine = {cosine:.3f}) ✓"


def _r11_spatial_extent_crs(m):
    """
    NEW — Check whether the layer's actual bounding box is plausible
    for the declared CRS and matches any region named in identifier/abstract.
    """
    ext    = m["spatial_extent"]
    authid = m["authid"]
    ident  = (m["identifier"] + " " + m["abstract"]).lower()

    if not ext["valid"]:
        return True, 0.0, "Empty spatial extent — skipped"

    xmin, ymin = ext["xmin"], ext["ymin"]
    xmax, ymax = ext["xmax"], ext["ymax"]

    # CRS plausibility: if declared EPSG:4326, coords should be in degree range
    if authid in GLOBAL_CRS:
        if not (-180 <= xmin <= 180 and -180 <= xmax <= 180
                and -90  <= ymin <= 90  and -90  <= ymax <= 90):
            return False, 0.80, (
                f"CRS is {authid} (degrees expected) but extent "
                f"({xmin:.0f},{ymin:.0f},{xmax:.0f},{ymax:.0f}) is out of degree range — "
                f"CRS may be wrong or fabricated"
            )

    # Region name vs extent check
    for region, (rx1, ry1, rx2, ry2) in REGION_BBOX.items():
        if region in ident:
            # Check if layer extent overlaps with the named region at all
            overlap = not (xmax < rx1 or xmin > rx2 or ymax < ry1 or ymin > ry2)
            if not overlap:
                return False, 0.75, (
                    f"Metadata names '{region}' but layer extent "
                    f"({xmin:.2f},{ymin:.2f},{xmax:.2f},{ymax:.2f}) "
                    f"does not overlap {region}'s expected bbox"
                )
            break

    return True, 0.0, "Spatial extent is consistent with declared CRS and region ✓"


def _r12_feature_count_plausibility(m):
    """
    NEW — Flag implausible feature counts given geometry type and abstract claims.
    """
    count     = m["feature_count"]
    geom      = m["geom_type"]
    abstract  = m["abstract"].lower()
    ident     = m["identifier"].lower()

    if count < 0:
        return True, 0.0, "Feature count unavailable — skipped"

    # Zero features on a layer claiming real data is suspicious
    if count == 0:
        return False, 0.70, "Layer has 0 features — possible empty/placeholder layer"

    # "National", "country", "global" scale datasets with suspiciously few features
    scale_hints = ["national", "country", "global", "world", "state", "district"]
    is_large_scale = any(h in abstract or h in ident for h in scale_hints)

    if is_large_scale and geom in ("POLYGON", "MULTIPOLYGON") and count < 3:
        return False, 0.60, (
            f"National/global polygon layer has only {count} feature(s) — suspicious"
        )

    if is_large_scale and geom in ("LINESTRING", "MULTILINESTRING") and count < 5:
        return False, 0.55, (
            f"National/global line layer has only {count} feature(s) — suspicious"
        )

    # Specific count claims in abstract vs actual
    count_match = re.search(r'\b(\d{2,})\s*(point|feature|record|location|site)s?\b',
                             abstract)
    if count_match:
        claimed = int(count_match.group(1))
        ratio   = min(count, claimed) / max(count, claimed)
        if ratio < 0.5:
            return False, 0.65, (
                f"Abstract claims ~{claimed} features but layer has {count} — "
                f"significant mismatch"
            )

    return True, 0.0, f"Feature count ({count}) is plausible for {geom} layer ✓"


def _r13_duplicate_template_detection(m):
    """
    NEW — Detect copy-pasted, boilerplate, or template metadata.
    Checks:
      1. Boilerplate phrases in abstract
      2. Internal repetition between title, identifier, abstract
      3. Abnormally low vocabulary entropy in abstract
    """
    abstract   = m["abstract"].lower()
    title      = m["title"].lower()
    identifier = m["identifier"].lower()

    if not abstract:
        return True, 0.0, "Empty abstract — skipped"

    # Check for known boilerplate phrases
    found_boilerplate = [p for p in BOILERPLATE_PHRASES if p in abstract]
    if len(found_boilerplate) >= 2:
        return False, 0.55, (
            f"Abstract contains {len(found_boilerplate)} boilerplate phrases: "
            f"{found_boilerplate[:2]}"
        )

    # Check for excessive overlap between title/identifier and abstract
    title_tokens = set(_tokenize(title + " " + identifier))
    abs_tokens   = set(_tokenize(abstract))
    if title_tokens and abs_tokens:
        overlap = len(title_tokens & abs_tokens) / len(title_tokens)
        if overlap > 0.85 and len(abstract) > 50:
            return False, 0.50, (
                f"Abstract is {overlap:.0%} identical in vocabulary to the title/identifier — "
                f"may be auto-generated or copied"
            )

    # Vocabulary entropy check
    abs_tokens_list = _tokenize(abstract)
    if len(abs_tokens_list) > 10:
        unique_ratio = len(set(abs_tokens_list)) / len(abs_tokens_list)
        if unique_ratio < 0.35:
            return False, 0.50, (
                f"Very low abstract vocabulary entropy ({unique_ratio:.2f}) — "
                f"may be repetitive/templated text"
            )

    return True, 0.0, "No duplicate or template patterns detected ✓"


def _r14_attribute_field_consistency(m):
    """
    NEW — Check whether attribute table field names are semantically
    consistent with what the abstract and keywords claim the layer contains.
    Only flags when metadata makes specific claims that are completely absent
    from the attribute schema.
    """
    field_names = m["field_names"]
    abstract    = m["abstract"].lower()
    kw_blob     = " ".join(m["keywords"]).lower()
    combined    = abstract + " " + kw_blob

    if not field_names:
        return True, 0.0, "No attribute fields found — skipped"
    if not abstract:
        return True, 0.0, "Empty abstract — skipped"

    # Domain-specific claim → expected field name stems
    domain_checks = [
        (["population", "demographic", "census"],
         ["pop", "popul", "demog", "census", "count", "num"],
         "population/demographic"),
        (["elevation", "altitude", "dem", "height"],
         ["elev", "alt", "height", "z", "dem", "hgt"],
         "elevation"),
        (["temperature", "climate", "thermal"],
         ["temp", "climate", "therm", "tmax", "tmin", "tavg"],
         "temperature/climate"),
        (["administrative", "boundary", "jurisdiction"],
         ["name", "code", "id", "adm", "admin", "nm"],
         "administrative boundary"),
        (["road", "highway", "street", "transport"],
         ["road", "name", "type", "class", "speed", "fclass"],
         "road network"),
    ]

    mismatches = []
    field_blob  = " ".join(field_names)

    for claim_words, expected_stems, domain in domain_checks:
        claims_domain = any(cw in combined for cw in claim_words)
        if not claims_domain:
            continue
        has_field = any(stem in field_blob for stem in expected_stems)
        if not has_field:
            mismatches.append(domain)

    if mismatches:
        return False, 0.55, (
            f"Metadata claims {', '.join(mismatches)} data but no related "
            f"attribute fields found in schema ({field_blob[:80]}...)"
        )

    return True, 0.0, "Attribute field names consistent with metadata claims ✓"


_ALL_RULES = [
    ("R1",  "Geometry–Keyword Agreement",       _r1_geom_keyword),
    ("R2",  "Geometry–Identifier Agreement",    _r2_geom_identifier),
    ("R3",  "Geometry–Abstract Consistency",    _r3_geom_abstract),
    ("R4",  "Identifier–Keyword Overlap",       _r4_identifier_keywords),
    ("R5",  "Date Logic",                       _r5_date_logic),
    ("R6",  "CRS–Identifier Plausibility",      _r6_crs_identifier),
    ("R7",  "Abstract Anomaly Detection",       _r7_abstract_anomaly),
    ("R8",  "Email Domain Consistency",         _r8_email_domain),
    ("R9",  "Keyword Redundancy",               _r9_keyword_redundancy),
    ("R10", "Abstract–Keyword Coherence",       _r10_abstract_keyword_coherence),
    ("R11", "Spatial Extent vs CRS",            _r11_spatial_extent_crs),
    ("R12", "Feature Count Plausibility",       _r12_feature_count_plausibility),
    ("R13", "Duplicate/Template Detection",     _r13_duplicate_template_detection),
    ("R14", "Attribute Field Consistency",      _r14_attribute_field_consistency),
]

# ---------------------------------------------------------------------------
# PUBLIC API
# ---------------------------------------------------------------------------

def run_semantic_check(layer):
    try:
        m = _extract_from_layer(layer)
    except Exception as e:
        return {
            "verdict":       "ERROR",
            "tier":          "ERROR",
            "anomaly_score": 0.0,
            "rules":         [],
            "fired_rules":   [],
            "summary":       f"Could not read layer metadata: {e}",
            "details":       f"Extraction error: {e}",
        }

    rule_results   = []
    weighted_score = 0.0

    for rid, name, fn in _ALL_RULES:
        try:
            passed, confidence, reason = fn(m)
        except Exception as e:
            passed, confidence, reason = True, 0.0, f"Rule error: {e}"
        weight       = RULE_WEIGHTS[rid]
        contribution = (0 if passed else confidence) * weight
        weighted_score += contribution
        rule_results.append({
            "id":           rid,
            "name":         name,
            "passed":       passed,
            "confidence":   round(confidence, 3),
            "reason":       reason,
            "weight":       weight,
            "contribution": round(contribution, 4),
        })

    anomaly_score = round(min(weighted_score, 1.0), 4)
    fired         = [r for r in rule_results if not r["passed"]]

    # Three-tier verdict
    if anomaly_score <= THRESHOLD_WARN:
        verdict = "CONSISTENT"
        tier    = "CONSISTENT"
    elif anomaly_score <= THRESHOLD_SUSPICIOUS:
        verdict = "WARN"
        tier    = "WARN"
    else:
        verdict = "SUSPICIOUS"
        tier    = "SUSPICIOUS"

    if verdict == "CONSISTENT":
        summary = (
            f"Semantically CONSISTENT — anomaly score {anomaly_score:.3f}. "
            f"All {len(rule_results)} rules passed."
        )
    elif verdict == "WARN":
        rule_names = ", ".join(r["id"] for r in fired)
        summary = (
            f"WARN — anomaly score {anomaly_score:.3f} "
            f"(review recommended). {len(fired)} rule(s) flagged: {rule_names}"
        )
    else:
        rule_names = ", ".join(r["id"] for r in fired)
        summary = (
            f"Semantically SUSPICIOUS — anomaly score {anomaly_score:.3f}. "
            f"{len(fired)} rule(s) failed: {rule_names}"
        )

    lines = [
        "═" * 58,
        "SEMANTIC CONSISTENCY CHECK  (v2 — 14 rules)",
        f"Layer     : {layer.name()}",
        f"Geometry  : {m['geom_type']}",
        f"CRS       : {m['authid']}",
        f"Identifier: {m['identifier']}",
        f"Features  : {m['feature_count']}",
        f"Score     : {anomaly_score:.3f}  "
        f"(CONSISTENT ≤{THRESHOLD_WARN} | WARN ≤{THRESHOLD_SUSPICIOUS} | SUSPICIOUS >{THRESHOLD_SUSPICIOUS})",
        f"Verdict   : {verdict}",
        "─" * 58,
        "RULE RESULTS",
    ]
    for r in rule_results:
        status = "✓ PASS" if r["passed"] else "✗ FAIL"
        lines.append(f"  [{r['id']:3s}] {status}  {r['name']}")
        lines.append(f"         {r['reason']}")
        if not r["passed"]:
            lines.append(
                f"         contribution: "
                f"{r['contribution']:.4f}  (weight {r['weight']} × conf {r['confidence']})"
            )
    if not fired:
        lines.append("\nNo rules failed — metadata appears internally consistent.")
    else:
        lines.append(f"\n{len(fired)} rule(s) flagged issues:")
        for r in fired:
            lines.append(f"  • [{r['id']}] {r['name']}: {r['reason']}")
    lines.append("═" * 58)

    return {
        "verdict":       verdict,
        "tier":          tier,
        "anomaly_score": anomaly_score,
        "rules":         rule_results,
        "fired_rules":   fired,
        "summary":       summary,
        "details":       "\n".join(lines),
    }
