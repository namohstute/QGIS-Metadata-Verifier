"""
metadata_reader.py
==================
Reads layer-level metadata from QGIS layer properties.

IMPORTANT DESIGN RULE:
    Every reader function here MUST return the EXACT SAME string
    on every call for unchanged data. Even one character difference
    between the export call and the verify call will cause a false
    TAMPERED result.

    Rules followed to ensure this:
    - Always strip() and use consistent separators
    - Never include volatile data (timestamps, memory addresses)
    - Sort any list before joining so order never varies
    - Use only stable QGIS API calls (authid not description for CRS)
    - Round floats to fixed decimal places
    - Return "" for missing/empty fields — never None or "None"

WHERE QGIS STORES METADATA:
    Two sources on the layer object:
    1. Layer properties directly:
           layer.crs()          -> coordinate reference system
           layer.wkbType()      -> geometry type
           layer.extent()       -> bounding box
           layer.featureCount() -> number of features
    2. QgsLayerMetadata object via layer.metadata():
           .identifier()  -> unique ID
           .title()       -> name
           .abstract()    -> description
           .contacts()    -> owner/organization
           .keywords()    -> source/tags
           .history()     -> lineage
           .constraints() -> accuracy, resolution, scale
"""

from qgis.core import QgsWkbTypes


def read_layer_metadata(layer, field_keys):
    """
    Read the requested metadata fields from a QGIS layer.

    Parameters:
        layer      : QgsVectorLayer object
        field_keys : list of field key strings to read

    Returns:
        dict { field_key: string_value }
        All values are plain strings.
        Missing or unreadable fields return "" — never None.
    """
    meta = layer.metadata()

    # Map each field key to a reader function
    # Each lambda returns a plain string — no objects, no lists
    reader_map = {
        "crs":                lambda: _read_crs(layer),
        "geometry_type":      lambda: _read_geometry_type(layer),
        "bbox":               lambda: _read_bbox(layer),
        "feature_count":      lambda: str(layer.featureCount()),
        "identifier":         lambda: (meta.identifier() or "").strip(),
        "title":              lambda: (meta.title() or "").strip(),
        "abstract":           lambda: (meta.abstract() or "").strip(),
        "owner":              lambda: _read_contacts(meta),
        "source":             lambda: _read_keywords(meta),
        "lineage":            lambda: _read_lineage(meta),
        "scale_denominator":  lambda: _read_scale(meta),
        "spatial_resolution": lambda: _read_resolution(meta),
        "accuracy":           lambda: _read_accuracy(meta),
        "date_created":       lambda: _read_date_created(meta),
        "date_modified":      lambda: _read_date_modified(meta),
    }

    result = {}
    for key in field_keys:
        if key in reader_map:
            result[key] = _safe_read(reader_map[key])
        else:
            # Unknown custom field — return empty
            result[key] = ""

    return result


def _safe_read(fn):
    """
    Call fn() safely. Return "" if anything goes wrong.
    This ensures one broken reader never crashes the whole export/verify.
    """
    try:
        val = fn()
        if val is None:
            return ""
        val = str(val).strip()
        # Treat these as empty — they mean the field was not filled in
        if val in ("None", "NULL", "null", "none"):
            return ""
        return val
    except Exception:
        return ""


def _read_crs(layer):
    """
    Read CRS as authid only — e.g. "EPSG:4326"
    We use authid() NOT description() because description can include
    version strings or WKT that changes between QGIS versions.
    authid is stable and short e.g. "EPSG:4326" or "EPSG:32644"
    """
    crs = layer.crs()
    if not crs.isValid():
        return ""
    return crs.authid().strip()


def _read_geometry_type(layer):
    """
    Read geometry type as a display string e.g. "Point", "LineString", "Polygon"
    QgsWkbTypes.displayString converts the integer type code to a readable name.
    """
    return QgsWkbTypes.displayString(layer.wkbType()).strip()


def _read_bbox(layer):
    """
    Read bounding box as "xmin,ymin,xmax,ymax"
    Rounded to 6 decimal places to avoid floating point noise
    where the last decimal might differ by 0.000000001 between calls.
    """
    extent = layer.extent()
    if extent.isNull():
        return ""
    xmin = round(extent.xMinimum(), 6)
    ymin = round(extent.yMinimum(), 6)
    xmax = round(extent.xMaximum(), 6)
    ymax = round(extent.yMaximum(), 6)
    return f"{xmin},{ymin},{xmax},{ymax}"


def _read_contacts(meta):
    """
    Read owner/contacts as "name|org;name|org"
    We sort the contacts list so order never varies between calls.
    """
    contacts = meta.contacts()
    if not contacts:
        return ""
    parts = []
    for c in contacts:
        name = (c.name or "").strip()
        org  = (c.organization or "").strip()
        if name or org:
            parts.append(f"{name}|{org}")
    # Sort so order is always the same regardless of how QGIS returns them
    return ";".join(sorted(parts))


def _read_keywords(meta):
    """
    Read all keywords flattened and sorted.
    meta.keywords() returns dict { vocabulary: [word, word, ...] }
    We flatten all words and sort them so the result is always
    the same regardless of dict iteration order.
    """
    kw_dict = meta.keywords()
    if not kw_dict:
        return ""
    all_words = []
    for words in kw_dict.values():
        for word in words:
            w = (word or "").strip()
            if w:
                all_words.append(w)
    # Sort ensures consistent order every time
    return ";".join(sorted(all_words))


def _read_lineage(meta):
    """
    Read processing history as "step1 | step2 | step3"
    meta.history() returns a list of strings.
    """
    history = meta.history()
    if not history:
        return ""
    parts = [h.strip() for h in history if h.strip()]
    # Do NOT sort lineage — order matters for processing steps
    # But we do strip each entry for consistency
    return " | ".join(parts)


def _read_scale(meta):
    """
    Read scale denominator from metadata constraints.
    In QGIS metadata tab this is under Spatial Extent section.
    The user types a value like "50000" meaning 1:50000 scale.
    It is stored as a constraint with type containing "scale".

    We search constraints for any entry whose type contains "scale".
    """
    for constraint in meta.constraints():
        ctype = (constraint.type or "").strip().lower()
        cval  = (constraint.constraint or "").strip()
        if "scale" in ctype and cval:
            return cval
    return ""


def _read_resolution(meta):
    """
    Read spatial resolution from metadata constraints.
    Similar to scale — stored as a constraint whose type contains "resolution".
    """
    for constraint in meta.constraints():
        ctype = (constraint.type or "").strip().lower()
        cval  = (constraint.constraint or "").strip()
        if "resolution" in ctype and cval:
            return cval
    return ""


def _read_accuracy(meta):
    """
    Read accuracy constraints.
    Returns all constraints that are not scale or resolution,
    joined as "type:value;type:value"
    Sorted so order is always the same.
    """
    parts = []
    for constraint in meta.constraints():
        ctype = (constraint.type or "").strip()
        cval  = (constraint.constraint or "").strip()
        if ctype and cval:
            # Skip scale and resolution — they have their own fields
            if "scale" not in ctype.lower() and "resolution" not in ctype.lower():
                parts.append(f"{ctype}:{cval}")
    return ";".join(sorted(parts))


def _read_date_created(meta):
    """
    Read creation date from metadata.
    Tries meta.dates() which returns QgsDateTimeRange list in newer QGIS.
    Falls back to empty string if not available.
    We do NOT fall back to XML parsing — that returns volatile XML
    snippets that can differ between calls.
    """
    try:
        for date_entry in meta.dates():
            dtype = str(date_entry.type).lower()
            if "creat" in dtype:
                val = str(date_entry.date).strip()
                if val and val not in ("None", ""):
                    return val
    except Exception:
        pass
    return ""


def _read_date_modified(meta):
    """
    Read last modified date from metadata.
    NOTE: This field is excluded from hashing by default in constants.py
    because QGIS automatically updates it on every save.
    Only include it if you specifically want to detect any save event.
    """
    try:
        for date_entry in meta.dates():
            dtype = str(date_entry.type).lower()
            if "modif" in dtype or "updat" in dtype:
                val = str(date_entry.date).strip()
                if val and val not in ("None", ""):
                    return val
    except Exception:
        pass
    return ""


def get_all_metadata_as_dict(layer, field_keys):
    """
    Returns metadata for display in the UI preview panel.
    Same as read_layer_metadata but named clearly for UI use.
    """
    return read_layer_metadata(layer, field_keys)
