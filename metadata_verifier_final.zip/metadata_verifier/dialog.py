import os
import json
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QTableWidget, QTableWidgetItem, QTabWidget,
    QWidget, QMessageBox, QHeaderView, QGroupBox,
    QListWidget, QListWidgetItem, QAbstractItemView,
    QSizePolicy, QFileDialog, QLineEdit, QTextEdit,
    QCheckBox, QScrollArea, QFrame, QSplitter,
    QInputDialog, QProgressBar
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QColor, QFont, QBrush
from qgis.core import QgsProject, Qgis, QgsMessageLog

from .db_manager import LocalDB, HashDB
from .hash_engine import compute_all_hashes, generate_salt, derive_key_from_password
from .metadata_reader import read_layer_metadata, get_all_metadata_as_dict
from .constants import DEFAULT_METADATA_FIELDS, DEFAULT_FIELD_KEYS
from .semantic_checker import run_semantic_check, _extract_from_layer
from .ml_detector import run_ml_detection

# ── COLOUR PALETTE ─────────────────────────────────────────────────────────
C_GREEN_BG  = "#e8f5e9"; C_GREEN_FG  = "#1B5E20"
C_RED_BG    = "#ffcdd2"; C_RED_FG    = "#B71C1C"
C_ORANGE_BG = "#fff3e0"; C_ORANGE_FG = "#E65100"
C_BLUE_BG   = "#e3f2fd"; C_BLUE_FG   = "#0D47A1"
C_PURPLE_BG = "#f3e5f5"; C_PURPLE_FG = "#4A148C"
C_YELLOW_BG = "#fffde7"; C_YELLOW_FG = "#F57F17"
C_GREY_BG   = "#f5f5f5"; C_GREY_FG   = "#333333"

BTN_BLUE   = ("background:#1976D2;color:white;padding:7px 18px;"
              "border-radius:4px;font-weight:bold;font-size:13px;")
BTN_GREEN  = ("background:#4CAF50;color:white;padding:7px 18px;"
              "border-radius:4px;font-weight:bold;font-size:13px;")
BTN_PURPLE = ("background:#7B1FA2;color:white;padding:7px 18px;"
              "border-radius:4px;font-weight:bold;font-size:13px;")
BTN_HOVER_BLUE   = "QPushButton{%s}QPushButton:hover{background:#1565C0;}QPushButton:disabled{background:#9E9E9E;}" % BTN_BLUE
BTN_HOVER_GREEN  = "QPushButton{%s}QPushButton:hover{background:#388E3C;}QPushButton:disabled{background:#9E9E9E;}" % BTN_GREEN
BTN_HOVER_PURPLE = "QPushButton{%s}QPushButton:hover{background:#6A1B9A;}QPushButton:disabled{background:#9E9E9E;}" % BTN_PURPLE

# ---------------------------------------------------------------------------
# EXPORT WORKER  (PBKDF2-aware)
# ---------------------------------------------------------------------------

class ExportWorker(QThread):
    status   = pyqtSignal(str)
    finished = pyqtSignal(dict)
    error    = pyqtSignal(str)

    def __init__(self, layer, selected_fields, db_path, owner_name, password):
        super().__init__()
        self.layer           = layer
        self.selected_fields = selected_fields
        self.db_path         = db_path
        self.owner_name      = owner_name
        self.password        = password

    def run(self):
        db = HashDB(self.db_path)
        ok, msg = db.open(create_new=False)
        if not ok:
            self.error.emit(f"Cannot open hash database: {msg}")
            return
        try:
            layer_name = self.layer.name()
            self.status.emit(f"Reading metadata from '{layer_name}'...")

            # PBKDF2: generate salt, derive key from password (key never stored)
            self.status.emit("Deriving HMAC key via PBKDF2 (310,000 iterations)...")
            salt_hex, iters = db.init_pbkdf2_salt()
            key_hex = derive_key_from_password(self.password, salt_hex, iters)
            self.status.emit(f"Key derived successfully (salt stored, key discarded).")

            metadata_dict = read_layer_metadata(self.layer, self.selected_fields)
            self.status.emit("\nRaw values read from layer:")
            for key in sorted(metadata_dict.keys()):
                val = metadata_dict[key]
                self.status.emit(f"  {key}: {repr(val) if val else '(empty)'}")

            layer_salt = generate_salt()
            result     = compute_all_hashes(metadata_dict, layer_salt, key_hex)

            self.status.emit("\nNormalized values hashed:")
            for key in sorted(result["normalized_data"].keys()):
                val = result["normalized_data"][key]
                self.status.emit(f"  {key}: {repr(val) if val else '(empty)'}")

            db.store_layer_hash(layer_name, result["combined_hash"],
                                layer_salt, self.selected_fields, self.owner_name)
            for field_key, field_hash in result["field_hashes"].items():
                db.store_field_hash(layer_name, field_key, field_hash,
                                    result["normalized_data"].get(field_key, ""))
            db.store_layer_info(layer_name, self.owner_name,
                                len(result["field_hashes"]))
            self.status.emit(
                f"\nExport complete: {len(result['field_hashes'])} field hashes stored."
            )
            self.finished.emit({
                "layer_name":  layer_name,
                "field_count": len(result["field_hashes"]),
                "fields":      self.selected_fields
            })
        except Exception as e:
            self.error.emit(str(e))
        finally:
            db.close()


# ---------------------------------------------------------------------------
# VERIFY WORKER  (PBKDF2-aware)
# ---------------------------------------------------------------------------

class VerifyWorker(QThread):
    status        = pyqtSignal(str)
    finished      = pyqtSignal(dict)
    error         = pyqtSignal(str)
    need_password = pyqtSignal()   # emitted to ask UI for password

    def __init__(self, layer, hash_db_path, local_db_path,
                 auto_generate=False, password=""):
        super().__init__()
        self.layer          = layer
        self.hash_db_path   = hash_db_path
        self.local_db_path  = local_db_path
        self.auto_generate  = auto_generate
        self.password       = password

    def run(self):
        hash_db  = HashDB(self.hash_db_path)
        ok, msg  = hash_db.open(create_new=False)
        if not ok:
            self.error.emit(f"Cannot open hash file: {msg}")
            return

        import sqlite3
        local_conn = sqlite3.connect(self.local_db_path)
        local_conn.row_factory = sqlite3.Row

        try:
            layer_name = self.layer.name()
            self.status.emit(f"Verifying '{layer_name}'...")

            stored_layer = hash_db.get_layer_hash(layer_name)
            if stored_layer is None:
                if self.auto_generate:
                    self._auto_generate(layer_name, hash_db, local_conn)
                else:
                    self._log(local_conn, layer_name, "NOT_FOUND", "", "")
                    self.finished.emit({
                        "result":          "NOT_FOUND",
                        "layer_name":      layer_name,
                        "tampered_fields": [],
                        "field_results":   {},
                        "current_values":  {},
                        "message": f"No hash found for '{layer_name}' in the owner file."
                    })
                return

            salt            = stored_layer["salt"]
            stored_combined = stored_layer["combined_hash"]
            fields          = stored_layer["fields_hashed"]

            self.status.emit(f"Found stored hash. Checking {len(fields)} fields...")

            # PBKDF2: re-derive key from password (never stored in DB)
            self.status.emit("Re-deriving HMAC key from password via PBKDF2...")
            key_hex = hash_db.derive_key(self.password)
            self.status.emit("Key re-derived successfully.")

            current_metadata = read_layer_metadata(self.layer, fields)
            result           = compute_all_hashes(current_metadata, salt, key_hex)
            computed_combined = result["combined_hash"]
            computed_fields   = result["field_hashes"]
            normalized_data   = result["normalized_data"]

            self.status.emit("\nCurrent normalized values:")
            for key in sorted(normalized_data.keys()):
                self.status.emit(f"  {key}: {repr(normalized_data[key])}")

            if computed_combined == stored_combined:
                self.status.emit("\nCombined hash: MATCH ✓ — all fields intact.")
                self._log(local_conn, layer_name, "MATCH",
                          computed_combined, stored_combined)
                self.finished.emit({
                    "result":          "MATCH",
                    "layer_name":      layer_name,
                    "tampered_fields": [],
                    "field_results":   {k: "MATCH" for k in fields},
                    "current_values":  normalized_data,
                    "stored_values":   normalized_data,
                    "message": "All metadata fields verified — no tampering detected."
                })
                return

            # Field-by-field
            self.status.emit("\nCombined hash MISMATCH — checking field by field...")
            stored_fields = hash_db.get_all_field_hashes(layer_name)
            tampered, field_results = [], {}

            for key in fields:
                computed_fh  = computed_fields.get(key, "")
                stored_entry = stored_fields.get(key)
                if stored_entry is None:
                    field_results[key] = "NOT_FOUND"
                elif computed_fh == stored_entry["field_hash"]:
                    field_results[key] = "MATCH"
                    self.status.emit(f"  {key}: MATCH ✓")
                else:
                    field_results[key] = "TAMPERED"
                    tampered.append(key)
                    self.status.emit(f"  {key}: TAMPERED ✗")

            self._log(local_conn, layer_name, "TAMPERED",
                      computed_combined, stored_combined, tampered,
                      f"Tampered: {', '.join(tampered)}")

            stored_values_ui = {
                k: stored_fields.get(k, {}).get("normalized_value", "N/A")
                for k in fields
            }
            self.finished.emit({
                "result":          "TAMPERED",
                "layer_name":      layer_name,
                "tampered_fields": tampered,
                "field_results":   field_results,
                "current_values":  normalized_data,
                "stored_values":   stored_values_ui,
                "message": f"{len(tampered)} field(s) changed: {', '.join(tampered)}"
            })

        except Exception as e:
            self.error.emit(str(e))
        finally:
            hash_db.close()
            local_conn.close()

    def _log(self, local_conn, layer_name, result,
             computed, stored, tampered=None, notes=""):
        try:
            now = __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            c = local_conn.cursor()
            c.execute("""
                INSERT INTO tamper_log
                    (layer_name, verified_at, result, combined_hash_computed,
                     combined_hash_stored, tampered_fields, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (layer_name, now, result, computed, stored,
                  __import__("json").dumps(tampered or []), notes))
            local_conn.commit()
            c.close()
        except Exception:
            pass

    def _auto_generate(self, layer_name, hash_db, local_conn):
        fields        = DEFAULT_FIELD_KEYS
        metadata_dict = read_layer_metadata(self.layer, fields)
        layer_salt    = generate_salt()
        salt_hex, iters = hash_db.init_pbkdf2_salt()
        key_hex       = derive_key_from_password(self.password or "auto", salt_hex, iters)
        result        = compute_all_hashes(metadata_dict, layer_salt, key_hex)
        hash_db.store_layer_hash(layer_name, result["combined_hash"],
                                 layer_salt, fields, "auto-generated")
        for key, fhash in result["field_hashes"].items():
            hash_db.store_field_hash(layer_name, key, fhash,
                                     result["normalized_data"].get(key, ""))
        hash_db.store_layer_info(layer_name, "auto-generated",
                                 len(result["field_hashes"]),
                                 "Auto-generated — no owner hash available.")
        self._log(local_conn, layer_name, "AUTO_GENERATED",
                  result["combined_hash"], "", [], "Auto-generated baseline.")
        self.finished.emit({
            "result":          "AUTO_GENERATED",
            "layer_name":      layer_name,
            "tampered_fields": [],
            "field_results":   {k: "AUTO_GENERATED" for k in fields},
            "current_values":  result["normalized_data"],
            "message": "Baseline hash auto-generated from current metadata."
        })


# ---------------------------------------------------------------------------
# SEMANTIC CHECK WORKER
# ---------------------------------------------------------------------------

class SemanticCheckWorker(QThread):
    status   = pyqtSignal(str)
    finished = pyqtSignal(dict)
    error    = pyqtSignal(str)

    def __init__(self, layer):
        super().__init__()
        self.layer = layer

    def run(self):
        try:
            self.status.emit(
                f"Running semantic consistency check on '{self.layer.name()}'..."
            )
            self.status.emit("Extracting metadata fields from layer...")
            result = run_semantic_check(self.layer)
            self.status.emit(
                f"Check complete — {len(result['rules'])} rules evaluated."
            )
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))


# ---------------------------------------------------------------------------
# ML DETECTOR WORKER
# ---------------------------------------------------------------------------

class MLDetectorWorker(QThread):
    """
    Runs the pre-trained ML anomaly detection model in a background thread.
    Receives the already-extracted layer_data dict from the semantic check
    so features are not extracted twice.
    """
    status   = pyqtSignal(str)
    finished = pyqtSignal(dict)
    error    = pyqtSignal(str)

    def __init__(self, layer, layer_data=None):
        super().__init__()
        self.layer      = layer
        self.layer_data = layer_data   # pre-extracted by semantic checker if available

    def run(self):
        try:
            self.status.emit(
                f"Running ML anomaly detection on '{self.layer.name()}'..."
            )
            # If layer_data was not pre-supplied, extract it now
            if self.layer_data is None:
                from .semantic_checker import _extract_from_layer
                self.status.emit("Extracting layer metadata features...")
                self.layer_data = _extract_from_layer(self.layer)

            self.status.emit(
                "Scoring with Isolation Forest + One-Class SVM ensemble..."
            )
            result = run_ml_detection(self.layer_data)
            self.status.emit(
                f"ML check complete — tamper probability: "
                f"{result['tamper_prob']*100:.1f}%"
            )
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))


# ---------------------------------------------------------------------------
# MAIN DIALOG
# ---------------------------------------------------------------------------

class MetadataVerifierDialog(QDialog):

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface    = iface
        self.local_db = None
        self.hash_db  = None
        self.worker   = None

        self.setWindowTitle("Metadata Integrity Verifier  v2")
        self.setMinimumWidth(1100)
        self.setMinimumHeight(820)
        self.setWindowFlags(Qt.Window)

        self._build_ui()
        self._connect_local_db()

    def _connect_local_db(self):
        self.local_db = LocalDB()
        success, msg = self.local_db.connect()
        if not success:
            QMessageBox.critical(self, "Database Error",
                f"Could not open local database:\n{msg}")

    def cleanup(self):
        if self.local_db:
            self.local_db.disconnect()
        if self.hash_db:
            self.hash_db.close()

    # ── UI CONSTRUCTION ────────────────────────────────────────────────────

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(4)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_owner_tab(),  "🔑  Owner: Generate Hashes")
        self.tabs.addTab(self._build_user_tab(),   "🔍  User: Verify Metadata (3 Pillars)")
        self.tabs.addTab(self._build_log_tab(),    "📋  Verification Log")
        layout.addWidget(self.tabs)

        self.status_label = QLabel("Ready.")
        self.status_label.setStyleSheet(
            "padding:4px; background:#f5f5f5; border-top:1px solid #ddd; font-size:12px;"
        )
        layout.addWidget(self.status_label)

    # ── OWNER TAB ──────────────────────────────────────────────────────────

    def _build_owner_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        info = QLabel(
            "Owner Mode: Read metadata from QGIS layer properties, compute "
            "HMAC-SHA256 hashes, and export a .db file to distribute with your layer.\n"
            "🔒  PBKDF2 password protection — your password is used to derive the HMAC key "
            "but is never stored anywhere."
        )
        info.setWordWrap(True)
        info.setStyleSheet(
            f"background:{C_GREEN_BG}; padding:10px; border-radius:6px; font-size:12px;"
        )
        layout.addWidget(info)

        # Layer selector
        lr = QHBoxLayout()
        lr.addWidget(QLabel("Layer:"))
        self.owner_layer_combo = QComboBox()
        self.owner_layer_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.owner_layer_combo.currentIndexChanged.connect(self.on_owner_layer_changed)
        lr.addWidget(self.owner_layer_combo)
        preview_btn = QPushButton("Preview Metadata")
        preview_btn.clicked.connect(self.preview_metadata)
        lr.addWidget(preview_btn)
        layout.addLayout(lr)

        # Field selector
        fields_group = QGroupBox("Metadata Fields to Hash")
        fg_layout = QVBoxLayout()
        fg_layout.addWidget(QLabel(
            "Default GIS-critical fields (pre-selected). "
            "Uncheck any to exclude, or add custom fields below."
        ))

        self.field_checkboxes = {}
        scroll = QScrollArea()
        scroll.setMaximumHeight(180)
        scroll.setWidgetResizable(True)
        scroll_widget = QWidget()
        scroll_layout = QVBoxLayout(scroll_widget)
        scroll_layout.setSpacing(2)

        for field in DEFAULT_METADATA_FIELDS:
            cb = QCheckBox(f"{field['label']}  —  {field['description']}")
            cb.setChecked(field.get("default_checked", True))
            cb.setObjectName(field["key"])
            self.field_checkboxes[field["key"]] = cb
            scroll_layout.addWidget(cb)

        scroll.setWidget(scroll_widget)
        fg_layout.addWidget(scroll)

        custom_row = QHBoxLayout()
        custom_row.addWidget(QLabel("Add custom field key:"))
        self.custom_field_input = QLineEdit()
        self.custom_field_input.setPlaceholderText("e.g. language, encoding ...")
        custom_row.addWidget(self.custom_field_input)
        add_custom_btn = QPushButton("Add")
        add_custom_btn.clicked.connect(self.add_custom_field)
        custom_row.addWidget(add_custom_btn)
        fg_layout.addLayout(custom_row)
        fields_group.setLayout(fg_layout)
        layout.addWidget(fields_group)

        # Owner name + export path
        name_row = QHBoxLayout()
        name_row.addWidget(QLabel("Your name / organization:"))
        self.owner_name_input = QLineEdit()
        self.owner_name_input.setPlaceholderText("e.g. Survey of India")
        name_row.addWidget(self.owner_name_input)
        layout.addLayout(name_row)

        path_row = QHBoxLayout()
        path_row.addWidget(QLabel("Save hash file as:"))
        self.export_path_input = QLineEdit()
        self.export_path_input.setReadOnly(True)
        self.export_path_input.setPlaceholderText("Choose save location...")
        path_row.addWidget(self.export_path_input)
        browse_btn = QPushButton("Browse")
        browse_btn.clicked.connect(self.browse_export_path)
        path_row.addWidget(browse_btn)
        layout.addLayout(path_row)

        self.generate_btn = QPushButton("🔐  Generate & Export Hashes")
        self.generate_btn.setStyleSheet(BTN_HOVER_BLUE)
        self.generate_btn.clicked.connect(self.start_export)
        layout.addWidget(self.generate_btn)

        self.owner_log = QTextEdit()
        self.owner_log.setReadOnly(True)
        self.owner_log.setPlaceholderText("Export progress will appear here...")
        self.owner_log.setStyleSheet("font-family: monospace; font-size: 12px;")
        layout.addWidget(self.owner_log)

        return widget

    # ── USER TAB ───────────────────────────────────────────────────────────

    def _build_user_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(4)

        # ── Layer selector ─────────────────────────────────────────────────
        lr = QHBoxLayout()
        lr.addWidget(QLabel("Layer to verify:"))
        self.user_layer_combo = QComboBox()
        self.user_layer_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        lr.addWidget(self.user_layer_combo)
        layout.addLayout(lr)

        # ── Hash file import ───────────────────────────────────────────────
        hash_group = QGroupBox("Owner Hash File  (Pillar 1 — HMAC)")
        hg = QVBoxLayout()
        hr = QHBoxLayout()
        hr.addWidget(QLabel("Hash file (.db):"))
        self.hash_path_input = QLineEdit()
        self.hash_path_input.setReadOnly(True)
        self.hash_path_input.setPlaceholderText(
            "Browse to the .db file received from the owner..."
        )
        hr.addWidget(self.hash_path_input)
        import_btn = QPushButton("Browse")
        import_btn.clicked.connect(self.browse_hash_file)
        hr.addWidget(import_btn)
        hg.addLayout(hr)
        self.hash_info_label = QLabel("")
        self.hash_info_label.setWordWrap(True)
        self.hash_info_label.setStyleSheet(
            f"background:{C_BLUE_BG}; padding:6px; border-radius:4px; font-size:12px;"
        )
        self.hash_info_label.setVisible(False)
        hg.addWidget(self.hash_info_label)
        hash_group.setLayout(hg)
        layout.addWidget(hash_group)

        # ── No hash file option ────────────────────────────────────────────
        no_hash_group = QGroupBox("If no owner hash file is available")
        ng = QHBoxLayout()
        self.auto_gen_checkbox = QCheckBox(
            "Auto-generate hashes from current metadata as my own baseline"
        )
        ng.addWidget(self.auto_gen_checkbox)
        ng.addStretch()
        no_hash_group.setLayout(ng)
        layout.addWidget(no_hash_group)

        # ── Three action buttons ───────────────────────────────────────────
        btn_row = QHBoxLayout()
        btn_row.setSpacing(6)

        self.verify_btn = QPushButton("✅  Pillar 1 — Verify Hash")
        self.verify_btn.setToolTip("HMAC hash check — requires owner .db file")
        self.verify_btn.setStyleSheet(BTN_HOVER_GREEN)
        self.verify_btn.clicked.connect(self.start_verification)
        btn_row.addWidget(self.verify_btn)

        self.semantic_btn = QPushButton("🔎  Pillar 2 — Semantic Check")
        self.semantic_btn.setToolTip(
            "14-rule internal consistency check — no baseline file needed."
        )
        self.semantic_btn.setStyleSheet(BTN_HOVER_PURPLE)
        self.semantic_btn.clicked.connect(self.start_semantic_check)
        btn_row.addWidget(self.semantic_btn)

        self.ml_btn = QPushButton("🤖  Pillar 3 — ML Detection")
        self.ml_btn.setToolTip(
            "Isolation Forest + One-Class SVM anomaly detection.\n"
            "No baseline file needed."
        )
        self.ml_btn.setStyleSheet(
            "QPushButton{background:#00695C;color:white;padding:7px 18px;"
            "border-radius:4px;font-weight:bold;font-size:13px;}"
            "QPushButton:hover{background:#004D40;}"
            "QPushButton:disabled{background:#9E9E9E;}"
        )
        self.ml_btn.clicked.connect(self.start_ml_detection)
        btn_row.addWidget(self.ml_btn)

        btn_row.addStretch()

        # Clear all results button
        clear_btn = QPushButton("🗑  Clear Results")
        clear_btn.setToolTip("Clear all results and reset all panels")
        clear_btn.setStyleSheet(
            "QPushButton{background:#757575;color:white;padding:7px 12px;"
            "border-radius:4px;font-size:12px;}"
            "QPushButton:hover{background:#616161;}"
        )
        clear_btn.clicked.connect(self._clear_all_results)
        btn_row.addWidget(clear_btn)
        layout.addLayout(btn_row)

        # ── Main results area: outer vertical splitter ─────────────────────
        # Top pane   : results tab widget (all three pillars side by side)
        # Bottom pane: activity log + HMAC field table
        outer_splitter = QSplitter(Qt.Vertical)
        outer_splitter.setChildrenCollapsible(False)

        # ── TOP PANE — Results tab widget (persists across runs) ───────────
        results_tabs = QTabWidget()
        results_tabs.setTabPosition(QTabWidget.North)
        results_tabs.setStyleSheet(
            "QTabBar::tab { min-width:160px; padding:6px 12px; font-size:12px; font-weight:bold; }"
            "QTabBar::tab:selected { border-bottom: 3px solid #1976D2; }"
        )

        # ── TAB 1 — HMAC Hash result ───────────────────────────────────────
        hmac_tab = QWidget()
        hmac_layout = QVBoxLayout(hmac_tab)
        hmac_layout.setContentsMargins(8, 8, 8, 8)

        self.result_banner = QLabel("Run  ✅ Pillar 1 — Verify Hash  to see results.")
        self.result_banner.setAlignment(Qt.AlignCenter)
        self.result_banner.setWordWrap(True)
        self.result_banner.setStyleSheet(
            f"font-size:14px; padding:10px; border-radius:6px; "
            f"background:{C_GREY_BG}; color:{C_GREY_FG};"
        )
        hmac_layout.addWidget(self.result_banner)

        hmac_layout.addWidget(QLabel("Field-by-field results:"))
        self.field_result_table = QTableWidget()
        self.field_result_table.setColumnCount(4)
        self.field_result_table.setHorizontalHeaderLabels([
            "Field", "Result", "Current Value (normalized)", "Owner Value"
        ])
        fh = self.field_result_table.horizontalHeader()
        fh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        fh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        fh.setSectionResizeMode(2, QHeaderView.Stretch)
        fh.setSectionResizeMode(3, QHeaderView.Stretch)
        self.field_result_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.field_result_table.setAlternatingRowColors(True)
        self.field_result_table.verticalHeader().setVisible(False)
        self.field_result_table.setSelectionBehavior(QTableWidget.SelectRows)
        hmac_layout.addWidget(self.field_result_table)
        results_tabs.addTab(hmac_tab, "🔐  Pillar 1 — Hash")

        # ── TAB 2 — Semantic result ────────────────────────────────────────
        sem_tab = QWidget()
        sem_layout = QVBoxLayout(sem_tab)
        sem_layout.setContentsMargins(8, 8, 8, 8)

        # Verdict + score bar
        sem_top_row = QHBoxLayout()
        self.sem_verdict_label = QLabel(
            "Run  🔎 Pillar 2 — Semantic Check  to see results."
        )
        self.sem_verdict_label.setAlignment(Qt.AlignCenter)
        self.sem_verdict_label.setWordWrap(True)
        self.sem_verdict_label.setStyleSheet(
            f"font-size:14px; padding:10px; border-radius:6px; "
            f"background:{C_GREY_BG}; color:{C_GREY_FG};"
        )
        sem_top_row.addWidget(self.sem_verdict_label, stretch=3)

        score_widget  = QWidget()
        score_layout  = QVBoxLayout(score_widget)
        score_layout.setContentsMargins(6, 0, 6, 0)
        self.sem_score_label = QLabel("Anomaly score: —")
        self.sem_score_label.setAlignment(Qt.AlignCenter)
        self.sem_score_label.setStyleSheet("font-size:12px; font-weight:bold;")
        self.sem_score_bar = QProgressBar()
        self.sem_score_bar.setMinimum(0)
        self.sem_score_bar.setMaximum(100)
        self.sem_score_bar.setValue(0)
        self.sem_score_bar.setTextVisible(False)
        self.sem_score_bar.setFixedHeight(14)
        score_layout.addWidget(self.sem_score_label)
        score_layout.addWidget(self.sem_score_bar)
        sem_top_row.addWidget(score_widget, stretch=1)
        sem_layout.addLayout(sem_top_row)

        # Cross-pillar warning
        self.sem_cross_label = QLabel("")
        self.sem_cross_label.setWordWrap(True)
        self.sem_cross_label.setStyleSheet(
            f"background:{C_YELLOW_BG}; color:{C_YELLOW_FG}; "
            "padding:6px; border-radius:4px; font-size:12px;"
        )
        self.sem_cross_label.setVisible(False)
        sem_layout.addWidget(self.sem_cross_label)

        # Rule-by-rule table — no max height, fills the tab
        sem_layout.addWidget(QLabel("Rule-by-rule breakdown (14 rules):"))
        self.sem_rule_table = QTableWidget()
        self.sem_rule_table.setColumnCount(4)
        self.sem_rule_table.setHorizontalHeaderLabels([
            "Rule", "Status", "Finding", "Score contribution"
        ])
        rh = self.sem_rule_table.horizontalHeader()
        rh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        rh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        rh.setSectionResizeMode(2, QHeaderView.Stretch)
        rh.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.sem_rule_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.sem_rule_table.setAlternatingRowColors(True)
        self.sem_rule_table.verticalHeader().setVisible(False)
        self.sem_rule_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.sem_rule_table.setWordWrap(True)
        sem_layout.addWidget(self.sem_rule_table)
        results_tabs.addTab(sem_tab, "🔎  Pillar 2 — Semantic")

        # ── TAB 3 — ML result ──────────────────────────────────────────────
        ml_tab  = QWidget()
        ml_vbox = QVBoxLayout(ml_tab)
        ml_vbox.setContentsMargins(8, 8, 8, 8)

        # Verdict + probability gauge
        ml_top_row = QHBoxLayout()
        self.ml_verdict_label = QLabel(
            "Run  🤖 Pillar 3 — ML Detection  to see results."
        )
        self.ml_verdict_label.setAlignment(Qt.AlignCenter)
        self.ml_verdict_label.setWordWrap(True)
        self.ml_verdict_label.setStyleSheet(
            f"font-size:14px; padding:10px; border-radius:6px; "
            f"background:{C_GREY_BG}; color:{C_GREY_FG};"
        )
        ml_top_row.addWidget(self.ml_verdict_label, stretch=3)

        gauge_widget = QWidget()
        gauge_layout = QVBoxLayout(gauge_widget)
        gauge_layout.setContentsMargins(6, 0, 6, 0)
        self.ml_prob_label = QLabel("Tamper probability: —")
        self.ml_prob_label.setAlignment(Qt.AlignCenter)
        self.ml_prob_label.setStyleSheet("font-size:12px; font-weight:bold;")
        self.ml_prob_bar = QProgressBar()
        self.ml_prob_bar.setMinimum(0)
        self.ml_prob_bar.setMaximum(100)
        self.ml_prob_bar.setValue(0)
        self.ml_prob_bar.setTextVisible(False)
        self.ml_prob_bar.setFixedHeight(14)
        gauge_layout.addWidget(self.ml_prob_label)
        gauge_layout.addWidget(self.ml_prob_bar)
        ml_top_row.addWidget(gauge_widget, stretch=1)
        ml_vbox.addLayout(ml_top_row)

        # Per-model score cards
        model_row = QHBoxLayout()
        self.ml_if_label = QLabel("Isolation Forest: —")
        self.ml_if_label.setAlignment(Qt.AlignCenter)
        self.ml_if_label.setStyleSheet(
            f"background:{C_BLUE_BG}; color:{C_BLUE_FG}; padding:8px; "
            "border-radius:4px; font-size:12px; font-weight:bold;"
        )
        model_row.addWidget(self.ml_if_label)
        self.ml_ocsvm_label = QLabel("One-Class SVM: —")
        self.ml_ocsvm_label.setAlignment(Qt.AlignCenter)
        self.ml_ocsvm_label.setStyleSheet(
            f"background:{C_PURPLE_BG}; color:{C_PURPLE_FG}; padding:8px; "
            "border-radius:4px; font-size:12px; font-weight:bold;"
        )
        model_row.addWidget(self.ml_ocsvm_label)
        ml_vbox.addLayout(model_row)

        ml_info = QLabel(
            "Trained on 304 real GIS metadata records (Copernicus Marine).  "
            "CLEAN < 35%  |  UNCERTAIN 35–60%  |  SUSPICIOUS > 60%"
        )
        ml_info.setWordWrap(True)
        ml_info.setStyleSheet("font-size:11px; color:#555; padding:2px;")
        ml_vbox.addWidget(ml_info)

        # Feature table — no max height
        ml_vbox.addWidget(QLabel("Feature values used by ML model (19 features):"))
        self.ml_feature_table = QTableWidget()
        self.ml_feature_table.setColumnCount(2)
        self.ml_feature_table.setHorizontalHeaderLabels(["Feature", "Value"])
        mfh = self.ml_feature_table.horizontalHeader()
        mfh.setSectionResizeMode(0, QHeaderView.Stretch)
        mfh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.ml_feature_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.ml_feature_table.setAlternatingRowColors(True)
        self.ml_feature_table.verticalHeader().setVisible(False)
        ml_vbox.addWidget(self.ml_feature_table)
        results_tabs.addTab(ml_tab, "🤖  Pillar 3 — ML")

        # Store reference so on_*_done can switch to the right tab
        self._results_tabs = results_tabs
        outer_splitter.addWidget(results_tabs)

        # ── BOTTOM PANE — Activity log ─────────────────────────────────────
        log_widget = QWidget()
        log_layout = QVBoxLayout(log_widget)
        log_layout.setContentsMargins(0, 4, 0, 0)
        log_label = QLabel("Activity log:")
        log_label.setStyleSheet("font-size:11px; color:#555;")
        log_layout.addWidget(log_label)
        self.verify_log = QTextEdit()
        self.verify_log.setReadOnly(True)
        self.verify_log.setStyleSheet("font-family: monospace; font-size: 11px;")
        self.verify_log.setPlaceholderText(
            "Run any pillar — detailed output appears here..."
        )
        log_layout.addWidget(self.verify_log)
        outer_splitter.addWidget(log_widget)

        # Sensible default split — results tabs get 70%, log gets 30%
        outer_splitter.setSizes([500, 200])
        layout.addWidget(outer_splitter)

        # Keep backward-compatible references — no-op wrappers
        # semantic_panel and ml_panel point to their tab widgets for compatibility
        self.semantic_panel = sem_tab
        self.ml_panel       = ml_tab

        return widget

    # _build_semantic_panel and _build_ml_panel removed —
    # their content is now built inline inside _build_user_tab
    # as tabs within self._results_tabs (QTabWidget)

    def _build_log_tab(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)

        filter_group = QGroupBox("Filter")
        fl = QHBoxLayout()
        fl.addWidget(QLabel("Layer:"))
        self.log_layer_combo = QComboBox()
        self.log_layer_combo.setMinimumWidth(150)
        fl.addWidget(self.log_layer_combo)
        fl.addWidget(QLabel("Result:"))
        self.log_result_combo = QComboBox()
        self.log_result_combo.addItems(
            ["ALL", "MATCH", "TAMPERED", "AUTO_GENERATED", "NOT_FOUND"]
        )
        fl.addWidget(self.log_result_combo)
        load_btn = QPushButton("Load Log")
        load_btn.clicked.connect(self.load_log)
        fl.addWidget(load_btn)
        fl.addStretch()
        filter_group.setLayout(fl)
        layout.addWidget(filter_group)

        self.log_stats_label = QLabel("")
        self.log_stats_label.setStyleSheet("font-size:12px; color:#555; padding:2px;")
        layout.addWidget(self.log_stats_label)

        self.log_table = QTableWidget()
        self.log_table.setColumnCount(5)
        self.log_table.setHorizontalHeaderLabels([
            "Timestamp", "Layer", "Result", "Tampered Fields", "Notes"
        ])
        lh = self.log_table.horizontalHeader()
        lh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        lh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        lh.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        lh.setSectionResizeMode(3, QHeaderView.Stretch)
        lh.setSectionResizeMode(4, QHeaderView.Stretch)
        self.log_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.log_table.setAlternatingRowColors(True)
        layout.addWidget(self.log_table)
        return widget

    # ── LAYER MANAGEMENT ───────────────────────────────────────────────────

    def load_layers(self):
        layers = [
            l for l in QgsProject.instance().mapLayers().values()
            if l.type() == 0
        ]
        for combo in [self.owner_layer_combo, self.user_layer_combo]:
            combo.blockSignals(True)
            combo.clear()
            for layer in layers:
                combo.addItem(layer.name(), layer.id())
            combo.blockSignals(False)

        self.log_layer_combo.clear()
        self.log_layer_combo.addItem("All Layers", None)
        for layer in layers:
            self.log_layer_combo.addItem(layer.name(), layer.name())

        if self.owner_layer_combo.count() > 0:
            self.on_owner_layer_changed()

    def on_owner_layer_changed(self):
        layer = self._get_layer(self.owner_layer_combo)
        if not layer or not self.local_db:
            return
        saved = self.local_db.get_field_config(layer.name())
        if saved:
            for key, cb in self.field_checkboxes.items():
                cb.setChecked(key in saved)

    def _get_layer(self, combo):
        layer_id = combo.currentData()
        return QgsProject.instance().mapLayer(layer_id) if layer_id else None

    def _get_selected_fields(self):
        fields = [
            key for key, cb in self.field_checkboxes.items()
            if cb.isChecked()
        ]
        return fields

    def add_custom_field(self):
        key = self.custom_field_input.text().strip().lower().replace(" ", "_")
        if not key:
            return
        cb = QCheckBox(f"{key}  (custom field)")
        cb.setChecked(True)
        cb.setObjectName(key)
        self.field_checkboxes[key] = cb
        scroll_widget = self.findChild(QScrollArea).widget()
        scroll_widget.layout().addWidget(cb)
        self.custom_field_input.clear()
        self.set_status(f"Custom field '{key}' added.", "blue")

    def preview_metadata(self):
        layer = self._get_layer(self.owner_layer_combo)
        if not layer:
            return
        selected = self._get_selected_fields()
        if not selected:
            return
        meta = read_layer_metadata(layer, selected)
        self.owner_log.clear()
        self.owner_log.append(
            f"Metadata preview for layer: {layer.name()}\n{'─' * 50}"
        )
        for key, val in meta.items():
            display = val if val else "(empty — not set in layer metadata)"
            self.owner_log.append(f"  {key:20s}: {display}")
        self.owner_log.append(
            f"\n{'─' * 50}\n"
            "Fields with empty values will be hashed as empty strings.\n"
            "Fill them in Layer Properties → Metadata tab for best results."
        )

    # ── OWNER: EXPORT ──────────────────────────────────────────────────────

    def browse_export_path(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Hash File", "", "SQLite Database (*.db)"
        )
        if path:
            if not path.endswith(".db"):
                path += ".db"
            self.export_path_input.setText(path)

    def start_export(self):
        layer = self._get_layer(self.owner_layer_combo)
        if not layer:
            self.set_status("No layer selected.", "red")
            return

        owner_name = self.owner_name_input.text().strip()
        if not owner_name:
            QMessageBox.warning(self, "Missing Info",
                "Please enter your name or organization.")
            return

        export_path = self.export_path_input.text().strip()
        if not export_path:
            QMessageBox.warning(self, "Missing Info",
                "Please choose where to save the hash file.")
            return

        selected_fields = self._get_selected_fields()
        if not selected_fields:
            QMessageBox.warning(self, "No Fields",
                "Please select at least one metadata field to hash.")
            return

        # ── PBKDF2 PASSWORD PROMPT ─────────────────────────────────────────
        password, ok = QInputDialog.getText(
            self,
            "Set Export Password",
            "Enter a password to protect this hash file.\n\n"
            "⚠  This password is NOT stored anywhere.\n"
            "    You must remember it — it will be needed for verification.\n"
            "    Share it securely with whoever needs to verify this layer.",
            QLineEdit.Password
        )
        if not ok or not password.strip():
            self.set_status("Export cancelled — no password provided.", "orange")
            return

        # Confirm password
        password2, ok2 = QInputDialog.getText(
            self, "Confirm Password",
            "Re-enter the same password to confirm:",
            QLineEdit.Password
        )
        if not ok2 or password != password2:
            QMessageBox.warning(self, "Password Mismatch",
                "Passwords do not match. Export cancelled.")
            return
        # ──────────────────────────────────────────────────────────────────

        if self.local_db:
            self.local_db.save_field_config(layer.name(), selected_fields)

        self.hash_db = HashDB(export_path)
        ok_db, msg_db = self.hash_db.open(create_new=True)
        if not ok_db:
            QMessageBox.critical(self, "Error", f"Cannot create file:\n{msg_db}")
            return

        self.generate_btn.setEnabled(False)
        self.owner_log.clear()
        self.owner_log.append(f"Starting export for layer: {layer.name()}\n")
        self.owner_log.append(
            "🔒 PBKDF2 key derivation: your password will be used to derive\n"
            "   the HMAC key (310,000 iterations). Key is NOT stored in the file.\n"
        )

        self.worker = ExportWorker(
            layer, selected_fields, export_path, owner_name, password
        )
        self.worker.status.connect(self.owner_log.append)
        self.worker.finished.connect(self.on_export_done)
        self.worker.error.connect(self.on_export_error)
        self.worker.start()
        self.set_status("Exporting hashes (deriving PBKDF2 key)...", "blue")

    def on_export_done(self, summary):
        self.generate_btn.setEnabled(True)
        path = self.export_path_input.text()
        self.owner_log.append(
            f"\n{'─'*50}\n"
            f"Export complete!\n"
            f"  Layer    : {summary['layer_name']}\n"
            f"  Fields   : {len(summary['fields'])}\n"
            f"  Hash file: {path}\n\n"
            f"Distribute this .db file with your layer.\n"
            f"Share your password separately and securely.\n"
            f"⚠  Do NOT lose your password — it cannot be recovered."
        )
        self.set_status(
            f"Done. {summary['field_count']} field hashes exported.", "green"
        )

    def on_export_error(self, msg):
        self.generate_btn.setEnabled(True)
        self.set_status(f"Export error: {msg}", "red")
        QMessageBox.critical(self, "Export Error", msg)

    # ── USER: VERIFY ───────────────────────────────────────────────────────

    def browse_hash_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Owner Hash File", "", "SQLite Database (*.db)"
        )
        if not path:
            return

        self.hash_path_input.setText(path)
        self.hash_db = HashDB(path)
        ok, msg = self.hash_db.open(create_new=False)
        if not ok:
            QMessageBox.critical(self, "Error", f"Cannot open file:\n{msg}")
            self.hash_db = None
            return

        layer = self._get_layer(self.user_layer_combo)
        if layer:
            info = self.hash_db.get_layer_info(layer.name())
            if info:
                self.hash_info_label.setText(
                    f"Layer: {info['layer_name']}  |  "
                    f"Created by: {info['created_by']}  |  "
                    f"Date: {info['created_at']}  |  "
                    f"Fields hashed: {info['field_count']}"
                )
                self.hash_info_label.setStyleSheet(
                    f"background:{C_GREEN_BG}; padding:6px; border-radius:4px; font-size:12px;"
                )
            else:
                available = self.hash_db.get_all_layer_names()
                self.hash_info_label.setText(
                    f"No hash found for layer '{layer.name()}' in this file.\n"
                    f"Layers available: {', '.join(available) or 'none'}"
                )
                self.hash_info_label.setStyleSheet(
                    f"background:{C_ORANGE_BG}; padding:6px; border-radius:4px; font-size:12px;"
                )
            self.hash_info_label.setVisible(True)
        self.set_status("Hash file loaded. Click Verify to start.", "green")

    def start_verification(self):
        if not self.local_db:
            return

        layer = self._get_layer(self.user_layer_combo)
        if not layer:
            self.set_status("No layer selected.", "red")
            return

        if self.hash_db is None or not self.hash_db.is_open():
            if not self.auto_gen_checkbox.isChecked():
                QMessageBox.information(
                    self, "No Hash File",
                    "No owner hash file is loaded.\n\n"
                    "Either:\n"
                    "  1. Browse to the .db file from the owner\n"
                    "  2. Check the auto-generate option"
                )
                return
            baseline_path = os.path.join(
                os.path.dirname(__file__), "self_baseline.db"
            )
            self.hash_db = HashDB(baseline_path)
            self.hash_db.open(create_new=False)

        # ── PBKDF2 PASSWORD PROMPT ─────────────────────────────────────────
        password, ok = QInputDialog.getText(
            self,
            "Enter Verification Password",
            "Enter the password provided by the data owner.\n\n"
            "The HMAC key will be re-derived from this password.\n"
            "Wrong password → all fields will show TAMPERED.",
            QLineEdit.Password
        )
        if not ok:
            self.set_status("Verification cancelled.", "orange")
            return
        # ──────────────────────────────────────────────────────────────────

        self.verify_btn.setEnabled(False)
        self.verify_log.clear()
        self.field_result_table.setRowCount(0)
        self.result_banner.setText("Verifying…")
        self.result_banner.setStyleSheet(
            f"font-size:14px; padding:10px; border-radius:6px; "
            f"background:{C_BLUE_BG}; color:{C_BLUE_FG};"
        )
        self._results_tabs.setCurrentIndex(0)

        hash_path  = self.hash_db.db_path if self.hash_db else ""
        local_path = self.local_db.get_path()
        self.worker = VerifyWorker(
            layer, hash_path, local_path,
            self.auto_gen_checkbox.isChecked(),
            password
        )
        self.worker.status.connect(self.verify_log.append)
        self.worker.finished.connect(self.on_verify_done)
        self.worker.error.connect(self.on_verify_error)
        self.worker.start()
        self.set_status(f"Verifying metadata of '{layer.name()}'...", "blue")

    def on_verify_done(self, summary):
        self.verify_btn.setEnabled(True)
        result = summary["result"]

        # Update HMAC banner inside tab 1
        if result == "MATCH":
            self.result_banner.setText(
                "✅  ALL METADATA FIELDS VERIFIED — NO TAMPERING DETECTED"
            )
            self.result_banner.setStyleSheet(
                f"font-size:14px; font-weight:bold; padding:10px; border-radius:6px; "
                f"background:{C_GREEN_BG}; color:{C_GREEN_FG};"
            )
            self._results_tabs.setTabText(0, "🔐  Pillar 1 — Hash  ✅")
            self.iface.messageBar().pushMessage(
                "Verification", "All metadata fields intact.",
                level=Qgis.Success, duration=6
            )
        elif result == "TAMPERED":
            fields = ", ".join(summary["tampered_fields"])
            self.result_banner.setText(
                f"❌  TAMPERING DETECTED — Fields changed: {fields}"
            )
            self.result_banner.setStyleSheet(
                f"font-size:14px; font-weight:bold; padding:10px; border-radius:6px; "
                f"background:{C_RED_BG}; color:{C_RED_FG};"
            )
            self._results_tabs.setTabText(0, "🔐  Pillar 1 — Hash  ❌")
            self.iface.messageBar().pushMessage(
                "Tampering Detected",
                f"Metadata tampered in fields: {fields}",
                level=Qgis.Critical, duration=10
            )
        elif result == "AUTO_GENERATED":
            self.result_banner.setText(
                "📝  BASELINE HASH AUTO-GENERATED FROM CURRENT METADATA"
            )
            self.result_banner.setStyleSheet(
                f"font-size:14px; font-weight:bold; padding:10px; border-radius:6px; "
                f"background:{C_BLUE_BG}; color:{C_BLUE_FG};"
            )
            self._results_tabs.setTabText(0, "🔐  Pillar 1 — Hash  📝")
        else:
            self.result_banner.setText("⚠️  LAYER NOT FOUND IN OWNER HASH FILE")
            self.result_banner.setStyleSheet(
                f"font-size:14px; font-weight:bold; padding:10px; border-radius:6px; "
                f"background:{C_ORANGE_BG}; color:{C_ORANGE_FG};"
            )
            self._results_tabs.setTabText(0, "🔐  Pillar 1 — Hash  ⚠️")

        # Populate field-by-field results table
        field_results  = summary.get("field_results", {})
        current_values = summary.get("current_values", {})
        stored_values  = summary.get("stored_values", {})
        colors = {
            "MATCH":          QColor(C_GREEN_BG),
            "TAMPERED":       QColor(C_RED_BG),
            "NOT_FOUND":      QColor(C_ORANGE_BG),
            "AUTO_GENERATED": QColor(C_BLUE_BG),
        }
        for field_key, field_result in sorted(field_results.items()):
            row = self.field_result_table.rowCount()
            self.field_result_table.insertRow(row)
            color       = colors.get(field_result, QColor("#ffffff"))
            current_val = current_values.get(field_key, "")
            owner_val   = stored_values.get(field_key, "N/A")
            for col, val in enumerate([field_key, field_result,
                                       current_val, owner_val]):
                item = QTableWidgetItem(str(val))
                item.setBackground(QBrush(color))
                if col == 1:
                    f = QFont(); f.setBold(True)
                    item.setFont(f)
                self.field_result_table.setItem(row, col, item)

        self.set_status(summary["message"],
                        "green" if result == "MATCH" else "red")

    def on_verify_error(self, msg):
        self.verify_btn.setEnabled(True)
        self.set_status(f"Error: {msg}", "red")
        QMessageBox.critical(self, "Error", msg)

    # ── SEMANTIC CHECK ─────────────────────────────────────────────────────

    def start_semantic_check(self):
        layer = self._get_layer(self.user_layer_combo)
        if not layer:
            self.set_status("No layer selected.", "red")
            return

        self.semantic_btn.setEnabled(False)
        self.sem_cross_label.setVisible(False)
        self._results_tabs.setCurrentIndex(1)
        self.verify_log.append(
            "\n" + "─" * 50 + "\nStarting semantic consistency check (v2 — 14 rules)...\n"
        )

        self.semantic_worker = SemanticCheckWorker(layer)
        self.semantic_worker.status.connect(self.verify_log.append)
        self.semantic_worker.finished.connect(self.on_semantic_done)
        self.semantic_worker.error.connect(self.on_semantic_error)
        self.semantic_worker.start()
        self.set_status(f"Running semantic check on '{layer.name()}'...", "purple")

    def on_semantic_done(self, result):
        self.semantic_btn.setEnabled(True)

        verdict = result["verdict"]
        tier    = result.get("tier", verdict)
        score   = result["anomaly_score"]
        fired   = result["fired_rules"]
        rules   = result["rules"]

        # Show raw log
        self.verify_log.append(result["details"])

        # ── Score bar ──────────────────────────────────────────────────────
        score_pct = int(score * 100)
        self.sem_score_bar.setValue(score_pct)
        self.sem_score_label.setText(f"Anomaly score: {score:.3f}  ({score_pct}%)")

        if tier == "CONSISTENT":
            bar_style = (
                "QProgressBar::chunk { background:#4CAF50; border-radius:3px; }"
                "QProgressBar { border:1px solid #ccc; border-radius:3px; background:#f5f5f5; }"
            )
        elif tier == "WARN":
            bar_style = (
                "QProgressBar::chunk { background:#FF9800; border-radius:3px; }"
                "QProgressBar { border:1px solid #ccc; border-radius:3px; background:#f5f5f5; }"
            )
        else:
            bar_style = (
                "QProgressBar::chunk { background:#F44336; border-radius:3px; }"
                "QProgressBar { border:1px solid #ccc; border-radius:3px; background:#f5f5f5; }"
            )
        self.sem_score_bar.setStyleSheet(bar_style)

        # ── Verdict banner ─────────────────────────────────────────────────
        if tier == "CONSISTENT":
            icon  = "🟢"
            label = "CONSISTENT"
            bg, fg = C_GREEN_BG, C_GREEN_FG
        elif tier == "WARN":
            icon  = "🟡"
            label = "WARN — review recommended"
            bg, fg = C_YELLOW_BG, C_YELLOW_FG
        else:
            icon  = "🔴"
            label = "SUSPICIOUS"
            bg, fg = C_RED_BG, C_RED_FG

        rule_ids = ", ".join(r["id"] for r in fired) if fired else "none"
        self.sem_verdict_label.setText(
            f"{icon}  {label}\n"
            f"{len(fired)} rule(s) flagged  |  rules: {rule_ids}"
        )
        self.sem_verdict_label.setStyleSheet(
            f"font-size:14px; font-weight:bold; padding:10px; border-radius:6px; "
            f"background:{bg}; color:{fg};"
        )

        # ── Cross-signal warning ───────────────────────────────────────────
        hmac_text = self.result_banner.text()
        if ("VERIFIED" in hmac_text or "NO TAMPERING" in hmac_text) \
                and tier in ("WARN", "SUSPICIOUS"):
            self.sem_cross_label.setText(
                "⚠  HMAC hash check passed (fields unchanged) but semantic check "
                f"flagged anomalies (score {score:.3f}). "
                "This may indicate metadata that is internally inconsistent but "
                "hasn't been cryptographically altered — manual review recommended."
            )
            self.sem_cross_label.setVisible(True)
        else:
            self.sem_cross_label.setVisible(False)

        # ── Rule table ─────────────────────────────────────────────────────
        self.sem_rule_table.setRowCount(0)
        for r in rules:
            row = self.sem_rule_table.rowCount()
            self.sem_rule_table.insertRow(row)

            status_text = "✓  PASS" if r["passed"] else "✗  FAIL"
            contrib     = f"{r['contribution']:.4f}" if not r["passed"] else "—"

            if r["passed"]:
                bg = QColor(C_GREEN_BG)
            elif r["confidence"] >= 0.70:
                bg = QColor(C_RED_BG)
            else:
                bg = QColor(C_ORANGE_BG)

            for col, val in enumerate([
                f"[{r['id']}] {r['name']}",
                status_text,
                r["reason"],
                contrib
            ]):
                item = QTableWidgetItem(str(val))
                item.setBackground(QBrush(bg))
                if col == 1:
                    f = QFont(); f.setBold(True)
                    item.setFont(f)
                self.sem_rule_table.setItem(row, col, item)

        # Update tab label to show verdict
        tab_icon = "🟢" if tier == "CONSISTENT" else "🟡" if tier == "WARN" else "🔴"
        self._results_tabs.setTabText(1, f"🔎  Pillar 2 — Semantic  {tab_icon}")
        self._results_tabs.setCurrentIndex(1)

        # QGIS message bar
        if tier == "CONSISTENT":
            self.iface.messageBar().pushMessage(
                "Semantic Check", "Metadata is internally consistent.",
                level=Qgis.Success, duration=5
            )
        elif tier == "WARN":
            self.iface.messageBar().pushMessage(
                "Semantic Check",
                f"Metadata has minor anomalies — review recommended ({len(fired)} rules flagged).",
                level=Qgis.Warning, duration=8
            )
        else:
            self.iface.messageBar().pushMessage(
                "Semantic Check",
                f"Metadata is SUSPICIOUS — {len(fired)} rule(s) failed.",
                level=Qgis.Critical, duration=10
            )

        self.set_status(result["summary"],
                        "green" if tier == "CONSISTENT"
                        else "orange" if tier == "WARN"
                        else "red")

    def on_semantic_error(self, msg):
        self.semantic_btn.setEnabled(True)
        self.set_status(f"Semantic check error: {msg}", "red")
        QMessageBox.critical(self, "Semantic Check Error", msg)

    # ── ML DETECTION (PILLAR 3) ────────────────────────────────────────────

    def start_ml_detection(self):
        """Run the ML anomaly detection model on the selected layer."""
        layer = self._get_layer(self.user_layer_combo)
        if not layer:
            self.set_status("No layer selected.", "red")
            return

        self.ml_btn.setEnabled(False)
        self._results_tabs.setCurrentIndex(2)
        self.verify_log.append(
            "\n" + "─" * 50 +
            "\nStarting ML anomaly detection (Pillar 3)...\n"
        )

        self.ml_worker = MLDetectorWorker(layer)
        self.ml_worker.status.connect(self.verify_log.append)
        self.ml_worker.finished.connect(self.on_ml_done)
        self.ml_worker.error.connect(self.on_ml_error)
        self.ml_worker.start()
        self.set_status(
            f"Running ML detection on '{layer.name()}'...", "teal"
        )

    def on_ml_done(self, result):
        """Display ML detection result in the panel."""
        self.ml_btn.setEnabled(True)

        verdict    = result["verdict"]
        tamper_prob= result["tamper_prob"]
        if_prob    = result["if_prob"]
        ocsvm_prob = result["ocsvm_prob"]
        if_flagged = result["if_flagged"]
        ocsvm_flagged = result["ocsvm_flagged"]

        if result.get("error"):
            self.set_status(f"ML error: {result['error']}", "red")
            QMessageBox.critical(self, "ML Detection Error", result["error"])
            return

        # ── Log details ────────────────────────────────────────────────────
        self.verify_log.append(result["details"])

        # ── Probability gauge ──────────────────────────────────────────────
        prob_pct = int(tamper_prob * 100)
        self.ml_prob_bar.setValue(prob_pct)
        self.ml_prob_label.setText(
            f"Tamper probability: {prob_pct}%  "
            f"(IF: {int(if_prob*100)}%  |  SVM: {int(ocsvm_prob*100)}%)"
        )

        if verdict == "CLEAN":
            bar_style = (
                "QProgressBar::chunk{background:#4CAF50;border-radius:4px;}"
                "QProgressBar{border:1px solid #ccc;border-radius:4px;background:#f5f5f5;}"
            )
            bg, fg    = C_GREEN_BG,  C_GREEN_FG
            icon, lbl = "🟢", "CLEAN — within normal GIS metadata patterns"
        elif verdict == "UNCERTAIN":
            bar_style = (
                "QProgressBar::chunk{background:#FF9800;border-radius:4px;}"
                "QProgressBar{border:1px solid #ccc;border-radius:4px;background:#f5f5f5;}"
            )
            bg, fg    = C_YELLOW_BG, C_YELLOW_FG
            icon, lbl = "🟡", "UNCERTAIN — some deviation from learned patterns"
        else:
            bar_style = (
                "QProgressBar::chunk{background:#F44336;border-radius:4px;}"
                "QProgressBar{border:1px solid #ccc;border-radius:4px;background:#f5f5f5;}"
            )
            bg, fg    = C_RED_BG,    C_RED_FG
            icon, lbl = "🔴", "SUSPICIOUS — significant deviation from normal patterns"

        self.ml_prob_bar.setStyleSheet(bar_style)

        # ── Verdict label ──────────────────────────────────────────────────
        self.ml_verdict_label.setText(f"{icon}  {lbl}\nTamper probability: {prob_pct}%")
        self.ml_verdict_label.setStyleSheet(
            f"font-size:14px; font-weight:bold; padding:10px; border-radius:6px; "
            f"background:{bg}; color:{fg};"
        )

        # ── Per-model labels ───────────────────────────────────────────────
        if_flag_txt = "FLAGGED ✗" if if_flagged else "CLEAN ✓"
        sv_flag_txt = "FLAGGED ✗" if ocsvm_flagged else "CLEAN ✓"
        self.ml_if_label.setText(
            f"Isolation Forest\n{int(if_prob*100)}%  {if_flag_txt}"
        )
        self.ml_ocsvm_label.setText(
            f"One-Class SVM\n{int(ocsvm_prob*100)}%  {sv_flag_txt}"
        )

        # ── Feature table ──────────────────────────────────────────────────
        self.ml_feature_table.setRowCount(0)
        features     = result.get("features", {})
        feature_cols = result.get("feature_cols", [])
        for col in feature_cols:
            val = features.get(col, 0.0)
            row = self.ml_feature_table.rowCount()
            self.ml_feature_table.insertRow(row)
            self.ml_feature_table.setItem(row, 0, QTableWidgetItem(col))
            self.ml_feature_table.setItem(row, 1, QTableWidgetItem(f"{val:.4f}"))

        # ── Cross-pillar check ─────────────────────────────────────────────
        hmac_text = self.result_banner.text()
        if "VERIFIED" in hmac_text and verdict == "SUSPICIOUS":
            self.verify_log.append(
                "\n⚠  CROSS-PILLAR ALERT: HMAC verified clean but ML flags "
                f"suspicious patterns ({prob_pct}% tamper probability). "
                "Semantic check recommended."
            )

        # tab already switched above — no setVisible needed
        # Update tab label and switch to ML tab
        ml_tab_icon = "🟢" if verdict == "CLEAN" else "🟡" if verdict == "UNCERTAIN" else "🔴"
        self._results_tabs.setTabText(2, f"🤖  Pillar 3 — ML  {ml_tab_icon}")
        self._results_tabs.setCurrentIndex(2)

        # ── QGIS message bar ───────────────────────────────────────────────
        if verdict == "CLEAN":
            self.iface.messageBar().pushMessage(
                "ML Detection", f"Metadata within normal patterns ({prob_pct}% tamper prob).",
                level=Qgis.Success, duration=5
            )
        elif verdict == "UNCERTAIN":
            self.iface.messageBar().pushMessage(
                "ML Detection", f"Some deviation detected ({prob_pct}% tamper prob).",
                level=Qgis.Warning, duration=7
            )
        else:
            self.iface.messageBar().pushMessage(
                "ML Detection", f"Suspicious metadata patterns ({prob_pct}% tamper prob).",
                level=Qgis.Critical, duration=10
            )

        self.set_status(result["summary"],
                        "green" if verdict == "CLEAN"
                        else "orange" if verdict == "UNCERTAIN"
                        else "red")

    def on_ml_error(self, msg):
        self.ml_btn.setEnabled(True)
        self.set_status(f"ML detection error: {msg}", "red")
        QMessageBox.critical(self, "ML Detection Error", msg)

    def _clear_all_results(self):
        """Reset all three result panels and the activity log to initial state."""
        # HMAC tab
        self.result_banner.setText(
            "Run  ✅ Pillar 1 — Verify Hash  to see results."
        )
        self.result_banner.setStyleSheet(
            f"font-size:14px; padding:10px; border-radius:6px; "
            f"background:{C_GREY_BG}; color:{C_GREY_FG};"
        )
        self.field_result_table.setRowCount(0)
        self._results_tabs.setTabText(0, "🔐  Pillar 1 — Hash")

        # Semantic tab
        self.sem_verdict_label.setText(
            "Run  🔎 Pillar 2 — Semantic Check  to see results."
        )
        self.sem_verdict_label.setStyleSheet(
            f"font-size:14px; padding:10px; border-radius:6px; "
            f"background:{C_GREY_BG}; color:{C_GREY_FG};"
        )
        self.sem_score_bar.setValue(0)
        self.sem_score_label.setText("Anomaly score: —")
        self.sem_rule_table.setRowCount(0)
        self.sem_cross_label.setVisible(False)
        self._results_tabs.setTabText(1, "🔎  Pillar 2 — Semantic")

        # ML tab
        self.ml_verdict_label.setText(
            "Run  🤖 Pillar 3 — ML Detection  to see results."
        )
        self.ml_verdict_label.setStyleSheet(
            f"font-size:14px; padding:10px; border-radius:6px; "
            f"background:{C_GREY_BG}; color:{C_GREY_FG};"
        )
        self.ml_prob_bar.setValue(0)
        self.ml_prob_label.setText("Tamper probability: —")
        self.ml_if_label.setText("Isolation Forest: —")
        self.ml_ocsvm_label.setText("One-Class SVM: —")
        self.ml_feature_table.setRowCount(0)
        self._results_tabs.setTabText(2, "🤖  Pillar 3 — ML")

        # Log
        self.verify_log.clear()
        self.set_status("All results cleared.", "black")

    # ── LOG TAB ────────────────────────────────────────────────────────────

    def load_log(self):
        if not self.local_db:
            return
        layer_name    = self.log_layer_combo.currentData()
        result_filter = self.log_result_combo.currentText()
        logs = self.local_db.get_tamper_log(
            layer_name=layer_name, result_filter=result_filter
        )
        self.log_table.setRowCount(0)
        counts = {}
        colors = {
            "TAMPERED":       QColor(C_RED_BG),
            "MATCH":          QColor(C_GREEN_BG),
            "AUTO_GENERATED": QColor(C_BLUE_BG),
            "NOT_FOUND":      QColor(C_ORANGE_BG),
        }
        for entry in logs:
            result = entry["result"]
            counts[result] = counts.get(result, 0) + 1
            row = self.log_table.rowCount()
            self.log_table.insertRow(row)
            color    = colors.get(result, QColor("#ffffff"))
            tampered = ", ".join(entry.get("tampered_fields", []))
            for col, val in enumerate([
                entry["verified_at"], entry["layer_name"],
                result, tampered, entry.get("notes", "")
            ]):
                item = QTableWidgetItem(str(val))
                item.setBackground(QBrush(color))
                self.log_table.setItem(row, col, item)

        stats = " | ".join([f"{k}: {v}" for k, v in counts.items()])
        self.log_stats_label.setText(f"{len(logs)} entries | {stats}")
        self.set_status(f"Loaded {len(logs)} log entries.")

    # ── HELPERS ────────────────────────────────────────────────────────────

    def set_mode(self, mode):
        tab_map = {"owner": 0, "user": 1, "log": 2}
        if mode in tab_map:
            self.tabs.setCurrentIndex(tab_map[mode])

    def set_status(self, msg, color="black"):
        self.status_label.setText(msg)
        self.status_label.setStyleSheet(
            f"padding:4px; background:#f5f5f5; border-top:1px solid #ddd; "
            f"font-size:12px; color:{color};"
        )

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.worker.wait()
        event.accept()
