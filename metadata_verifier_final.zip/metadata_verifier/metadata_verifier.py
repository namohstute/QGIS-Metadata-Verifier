import os
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsMessageLog, Qgis
from .dialog import MetadataVerifierDialog


class MetadataVerifier:
    """
    Main plugin class. QGIS creates one instance when the plugin loads.
    Adds menu items and opens the dialog when user clicks them.
    """

    def __init__(self, iface):
        self.iface = iface
        self.dialog = None
        self.actions = []
        self.menu = "Metadata Integrity Verifier"

    def initGui(self):
        self.owner_action = QAction(
            "Owner: Generate & Export Hashes", self.iface.mainWindow()
        )
        self.owner_action.triggered.connect(lambda: self.open_dialog("owner"))
        self.iface.addToolBarIcon(self.owner_action)
        self.iface.addPluginToMenu(self.menu, self.owner_action)
        self.actions.append(self.owner_action)

        self.user_action = QAction(
            "User: Verify Layer Metadata", self.iface.mainWindow()
        )
        self.user_action.triggered.connect(lambda: self.open_dialog("user"))
        self.iface.addPluginToMenu(self.menu, self.user_action)
        self.actions.append(self.user_action)

        self.log_action = QAction(
            "View Verification Log", self.iface.mainWindow()
        )
        self.log_action.triggered.connect(lambda: self.open_dialog("log"))
        self.iface.addPluginToMenu(self.menu, self.log_action)
        self.actions.append(self.log_action)

        QgsMessageLog.logMessage(
            "Metadata Integrity Verifier loaded.", "MetadataVerifier", Qgis.Info
        )

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        if self.dialog is not None:
            self.dialog.cleanup()
            self.dialog.close()
            self.dialog = None

    def open_dialog(self, mode="user"):
        if self.dialog is None:
            self.dialog = MetadataVerifierDialog(self.iface)
        self.dialog.set_mode(mode)
        self.dialog.load_layers()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
