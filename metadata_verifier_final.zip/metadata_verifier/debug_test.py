"""
debug_test.py
=============
Run this from QGIS Python Console to diagnose why all fields show TAMPERED.

HOW TO USE:
    1. Open QGIS
    2. Load your layer
    3. Go to Plugins -> Python Console
    4. Run:
           import sys
           sys.path.insert(0, "C:/path/to/plugin/parent/folder")
           exec(open("C:/path/to/metadata_verifier/debug_test.py").read())
"""

import sqlite3
import json

def debug_verify(layer_name, db_path):
    """
    Reads stored hashes from the DB and re-reads current metadata,
    then prints EXACTLY what string was hashed in each case.
    This tells you precisely where the mismatch is.
    """
    from qgis.core import QgsProject
    from metadata_verifier.metadata_reader import read_layer_metadata
    from metadata_verifier.hash_engine import compute_hmac, normalize_value, SECRET_KEY

    # Get the layer
    layers = [l for l in QgsProject.instance().mapLayers().values()
              if l.name() == layer_name]
    if not layers:
        print(f"Layer '{layer_name}' not found in QGIS.")
        return
    layer = layers[0]

    # Open DB
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    # Get stored layer record
    c = conn.cursor()
    c.execute("SELECT * FROM layer_hashes WHERE layer_name = ?", (layer_name,))
    row = c.fetchone()
    if not row:
        print(f"No hash found for layer '{layer_name}' in {db_path}")
        conn.close()
        return

    salt   = row["salt"]
    fields = json.loads(row["fields_hashed"])
    print(f"\nLayer   : {layer_name}")
    print(f"Salt    : {salt[:16]}...")
    print(f"Fields  : {fields}")
    print(f"\n{'='*70}")

    # Get stored field hashes
    c.execute("SELECT * FROM field_hashes WHERE layer_name = ?", (layer_name,))
    stored = {r["field_key"]: dict(r) for r in c.fetchall()}
    conn.close()

    # Read current metadata
    current = read_layer_metadata(layer, fields)

    print(f"\n{'Field':<22} {'Stored Value':<35} {'Current Value':<35} {'Match?'}")
    print("-"*100)

    all_match = True
    for key in sorted(fields):
        stored_norm  = stored.get(key, {}).get("normalized_value", "NOT IN DB")
        stored_hash  = stored.get(key, {}).get("field_hash", "")
        current_raw  = current.get(key, "")
        current_norm = normalize_value(current_raw)
        current_hash = compute_hmac(current_norm, salt)

        match = "YES" if stored_hash == current_hash else "NO ❌"
        if stored_hash != current_hash:
            all_match = False

        print(f"{key:<22} {repr(stored_norm):<35} {repr(current_norm):<35} {match}")

        if stored_hash != current_hash and stored_norm == current_norm:
            print(f"  ⚠ VALUES ARE SAME BUT HASH DIFFERS — salt or algorithm mismatch!")
            print(f"  Stored hash : {stored_hash[:20]}...")
            print(f"  Current hash: {current_hash[:20]}...")

    print("-"*100)
    if all_match:
        print("✅ ALL FIELDS MATCH — no tampering")
    else:
        print("❌ SOME FIELDS DIFFER — see above")

# Call this — replace with your actual layer name and db path
# debug_verify("IITK_Building_Layer", r"C:\Users\kanika sharma\Downloads\432_prj\building1_hash.db")
