"""
db_manager.py — PBKDF2 upgrade
The key_store table now stores pbkdf2_salt + pbkdf2_iters instead of a raw key.
The derived key is NEVER stored — it is re-derived from password on every use.
"""
import sqlite3
import json
import os
from datetime import datetime
from .constants import LOCAL_DB_PATH


class LocalDB:
    def __init__(self):
        self.conn = None
        self.path = LOCAL_DB_PATH

    def connect(self):
        try:
            self.conn = sqlite3.connect(self.path)
            self.conn.row_factory = sqlite3.Row
            self._create_tables()
            return True, "Local database ready."
        except Exception as e:
            return False, str(e)

    def disconnect(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def is_connected(self):
        return self.conn is not None

    def get_path(self):
        return self.path

    def _create_tables(self):
        c = self.conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS tamper_log (
                id                     INTEGER PRIMARY KEY AUTOINCREMENT,
                layer_name             TEXT NOT NULL,
                verified_at            TEXT NOT NULL,
                result                 TEXT NOT NULL,
                combined_hash_computed TEXT NOT NULL,
                combined_hash_stored   TEXT DEFAULT '',
                tampered_fields        TEXT DEFAULT '',
                notes                  TEXT DEFAULT ''
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS layer_field_config (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                layer_name      TEXT UNIQUE NOT NULL,
                selected_fields TEXT NOT NULL,
                updated_at      TEXT NOT NULL
            )
        """)
        self.conn.commit()
        c.close()

    def log_verification(self, layer_name, result, combined_computed,
                         combined_stored="", tampered_fields=None, notes=""):
        c = self.conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c.execute("""
            INSERT INTO tamper_log
                (layer_name, verified_at, result, combined_hash_computed,
                 combined_hash_stored, tampered_fields, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (layer_name, now, result, combined_computed,
              combined_stored, json.dumps(tampered_fields or []), notes))
        self.conn.commit()
        c.close()

    def get_tamper_log(self, layer_name=None, result_filter=None, limit=200):
        c = self.conn.cursor()
        sql = "SELECT * FROM tamper_log"
        conditions, params = [], []
        if layer_name:
            conditions.append("layer_name = ?")
            params.append(layer_name)
        if result_filter and result_filter != "ALL":
            conditions.append("result = ?")
            params.append(result_filter)
        if conditions:
            sql += " WHERE " + " AND ".join(conditions)
        sql += " ORDER BY verified_at DESC LIMIT ?"
        params.append(limit)
        c.execute(sql, params)
        rows = [dict(r) for r in c.fetchall()]
        c.close()
        for row in rows:
            try:
                row["tampered_fields"] = json.loads(row.get("tampered_fields", "[]"))
            except Exception:
                row["tampered_fields"] = []
        return rows

    def save_field_config(self, layer_name, selected_fields):
        c = self.conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c.execute("""
            INSERT OR REPLACE INTO layer_field_config
                (layer_name, selected_fields, updated_at)
            VALUES (?, ?, ?)
        """, (layer_name, json.dumps(selected_fields), now))
        self.conn.commit()
        c.close()

    def get_field_config(self, layer_name):
        c = self.conn.cursor()
        c.execute(
            "SELECT selected_fields FROM layer_field_config WHERE layer_name = ?",
            (layer_name,)
        )
        row = c.fetchone()
        c.close()
        return json.loads(row["selected_fields"]) if row else []


class HashDB:
    """
    Manages hashes.db.

    PBKDF2 UPGRADE:
        key_store now stores pbkdf2_salt + pbkdf2_iters.
        The raw HMAC key is NEVER stored — derived from password on use.

    TABLES:
        key_store    : pbkdf2_salt, pbkdf2_iters (no raw key)
        layer_hashes : combined_hash, salt, fields list
        field_hashes : per-field hash + normalized value
        layer_info   : human readable summary
    """

    def __init__(self, db_path):
        self.db_path = db_path
        self.conn    = None

    def open(self, create_new=False):
        try:
            if create_new and os.path.exists(self.db_path):
                os.remove(self.db_path)
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row
            self._create_tables()
            return True, "OK"
        except Exception as e:
            return False, str(e)

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def is_open(self):
        return self.conn is not None

    def _create_tables(self):
        c = self.conn.cursor()
        # PBKDF2 salt storage — no raw key ever stored
        c.execute("""
            CREATE TABLE IF NOT EXISTS key_store (
                id            INTEGER PRIMARY KEY CHECK (id = 1),
                pbkdf2_salt   TEXT NOT NULL,
                pbkdf2_iters  INTEGER NOT NULL,
                created_at    TEXT NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS layer_hashes (
                layer_name    TEXT PRIMARY KEY NOT NULL,
                combined_hash TEXT NOT NULL,
                salt          TEXT NOT NULL,
                fields_hashed TEXT NOT NULL,
                created_by    TEXT NOT NULL,
                created_at    TEXT NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS field_hashes (
                layer_name       TEXT NOT NULL,
                field_key        TEXT NOT NULL,
                field_hash       TEXT NOT NULL,
                normalized_value TEXT NOT NULL,
                created_at       TEXT NOT NULL,
                PRIMARY KEY (layer_name, field_key)
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS layer_info (
                layer_name  TEXT PRIMARY KEY NOT NULL,
                created_by  TEXT NOT NULL,
                created_at  TEXT NOT NULL,
                field_count INTEGER NOT NULL,
                notes       TEXT DEFAULT ''
            )
        """)
        self.conn.commit()
        c.close()

    # ── PBKDF2 KEY MANAGEMENT ────────────────────────────────────────────

    def init_pbkdf2_salt(self, iterations=310_000):
        """
        Generate and store a fresh PBKDF2 salt for a new export.
        Called once when the owner creates a new hashes.db.
        Returns the salt_hex so the caller can immediately derive the key.
        """
        from .hash_engine import generate_pbkdf2_salt
        salt = generate_pbkdf2_salt()
        now  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c    = self.conn.cursor()
        c.execute(
            "INSERT OR REPLACE INTO key_store (id, pbkdf2_salt, pbkdf2_iters, created_at)"
            " VALUES (1, ?, ?, ?)",
            (salt, iterations, now)
        )
        self.conn.commit()
        c.close()
        return salt, iterations

    def get_pbkdf2_params(self):
        """
        Retrieve stored PBKDF2 salt and iterations from the DB.
        Returns (salt_hex, iterations) or (None, None) if not found.
        """
        c = self.conn.cursor()
        c.execute("SELECT pbkdf2_salt, pbkdf2_iters FROM key_store WHERE id = 1")
        row = c.fetchone()
        c.close()
        if row:
            return row["pbkdf2_salt"], row["pbkdf2_iters"]
        return None, None

    def derive_key(self, password: str) -> str:
        """
        Derive the HMAC key from the owner password + stored PBKDF2 salt.
        Returns key_hex string. Raises ValueError if no salt stored yet.
        """
        from .hash_engine import derive_key_from_password
        salt, iters = self.get_pbkdf2_params()
        if salt is None:
            raise ValueError("No PBKDF2 salt found in this database. "
                             "Was it created with the current plugin version?")
        return derive_key_from_password(password, salt, iters)

    # ── WRITE ────────────────────────────────────────────────────────────

    def store_layer_hash(self, layer_name, combined_hash, salt,
                         fields_hashed, created_by):
        c   = self.conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c.execute("""
            INSERT OR REPLACE INTO layer_hashes
                (layer_name, combined_hash, salt, fields_hashed,
                 created_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (layer_name, combined_hash, salt,
              json.dumps(fields_hashed), created_by, now))
        self.conn.commit()
        c.close()

    def store_field_hash(self, layer_name, field_key,
                         field_hash, normalized_value):
        c   = self.conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c.execute("""
            INSERT OR REPLACE INTO field_hashes
                (layer_name, field_key, field_hash,
                 normalized_value, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (layer_name, field_key, field_hash, normalized_value, now))
        self.conn.commit()
        c.close()

    def store_layer_info(self, layer_name, created_by, field_count, notes=""):
        c   = self.conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c.execute("""
            INSERT OR REPLACE INTO layer_info
                (layer_name, created_by, created_at, field_count, notes)
            VALUES (?, ?, ?, ?, ?)
        """, (layer_name, created_by, now, field_count, notes))
        self.conn.commit()
        c.close()

    # ── READ ─────────────────────────────────────────────────────────────

    def get_layer_hash(self, layer_name):
        c = self.conn.cursor()
        c.execute("SELECT * FROM layer_hashes WHERE layer_name = ?", (layer_name,))
        row = c.fetchone()
        c.close()
        if not row:
            return None
        result = dict(row)
        result["fields_hashed"] = json.loads(result["fields_hashed"])
        return result

    def get_all_field_hashes(self, layer_name):
        c = self.conn.cursor()
        c.execute("""
            SELECT field_key, field_hash, normalized_value
            FROM field_hashes WHERE layer_name = ?
        """, (layer_name,))
        rows = c.fetchall()
        c.close()
        return {
            row["field_key"]: {
                "field_hash":       row["field_hash"],
                "normalized_value": row["normalized_value"]
            }
            for row in rows
        }

    def get_layer_info(self, layer_name):
        c = self.conn.cursor()
        c.execute("SELECT * FROM layer_info WHERE layer_name = ?", (layer_name,))
        row = c.fetchone()
        c.close()
        return dict(row) if row else None

    def get_all_layer_names(self):
        c = self.conn.cursor()
        c.execute("SELECT layer_name FROM layer_info ORDER BY layer_name")
        rows = c.fetchall()
        c.close()
        return [row["layer_name"] for row in rows]
