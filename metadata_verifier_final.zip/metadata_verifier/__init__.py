def classFactory(iface):
    from .metadata_verifier import MetadataVerifier
    return MetadataVerifier(iface)
