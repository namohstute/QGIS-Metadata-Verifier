"""
ml_detector.py
==============
Third Verification Pillar — ML-Based Anomaly Detection
CE432 Group 2 — Metadata Integrity Verifier

WHAT THIS MODULE DOES
---------------------
Unlike HMAC (needs a baseline file) and the semantic checker (rule-based),
this module uses trained ML models to compute a tamper probability score
purely from statistical patterns learned from 304 real GIS metadata records.

No original baseline file is needed.
No hardcoded rules are used.
The models learned what "normal" GIS metadata looks like and flag deviations.

MODELS
------
Isolation Forest  : flags records that are statistically easy to isolate
                    from the learned normal distribution
One-Class SVM     : flags records that fall outside the learned boundary
                    around normal metadata patterns
Ensemble          : combined probability from both models

FEATURES USED (19 GIS-specific)
--------------------------------
Abstract: length, word count, vocabulary entropy
Title   : length, word count, overlap with abstract
BBox    : west, east, south, north, width, height, area, center lat/lon
Date    : year, month of creation
CRS     : encoded category (WGS84=1, Equirect=2, Mercator=3, Polar=4)
Keywords: count

TRAINING DATA
-------------
304 real open-source GIS metadata records from Copernicus Marine Service.
Model is pre-trained and shipped as model_bundle.pkl inside the plugin folder.
"""

import os
import re
import math
import pickle
import warnings
from collections import Counter

warnings.filterwarnings("ignore")

# Path to the pre-trained model bundle (same directory as this file)
_BUNDLE_PATH = os.path.join(os.path.dirname(__file__), "model_bundle.pkl")

# Module-level cache — load once, reuse across calls
_bundle = None


def _load_bundle():
    """Load the model bundle from disk. Cached after first load."""
    global _bundle
    if _bundle is not None:
        return _bundle
    if not os.path.exists(_BUNDLE_PATH):
        raise FileNotFoundError(
            f"ML model bundle not found at: {_BUNDLE_PATH}\n"
            "Please ensure model_bundle.pkl is present in the plugin folder."
        )
    with open(_BUNDLE_PATH, "rb") as f:
        _bundle = pickle.load(f)
    return _bundle


# ---------------------------------------------------------------------------
# FEATURE ENGINEERING
# Mirrors exactly what was used during training in build_model_bundle.py
# ---------------------------------------------------------------------------

def _vocab_entropy(text):
    """Vocabulary entropy — low entropy signals repetitive/boilerplate text."""
    if not isinstance(text, str) or len(text) < 10:
        return 0.0
    tokens = re.findall(r"[a-z]+", text.lower())
    if len(tokens) < 5:
        return 0.0
    total  = len(tokens)
    counts = Counter(tokens)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def _title_abstract_overlap(title, abstract):
    """Token overlap ratio between title and abstract (excluding stopwords)."""
    stopwords = {
        "a","an","the","and","or","of","in","to","for","is","are",
        "was","were","with","this","that","from","on","at","by","it"
    }
    t_tok = set(re.findall(r"[a-z]+", str(title).lower()))   - stopwords
    a_tok = set(re.findall(r"[a-z]+", str(abstract).lower())) - stopwords
    if not t_tok:
        return 0.0
    return len(t_tok & a_tok) / len(t_tok)


def _encode_crs(authid):
    """
    Map a QGIS CRS authid string to a numeric category.
    Must mirror the training encoding exactly.
    """
    if not authid:
        return 0.0
    v = str(authid)
    if "4326" in v:                                           return 1.0
    if "32662" in v or "equirectangular" in v.lower() \
       or "Plate" in v or "regular" in v.lower():            return 2.0
    if "3395" in v or "Mercator" in v or "mercator" in v:    return 3.0
    if "polar" in v.lower() or "stereographic" in v.lower(): return 4.0
    if "41001" in v:                                          return 3.0
    return 5.0


def _extract_features(layer_data: dict) -> dict:
    """
    Convert the metadata dict produced by semantic_checker._extract_from_layer()
    into the 19 numeric features the ML model expects.

    Parameters
    ----------
    layer_data : dict
        Output of _extract_from_layer() — contains geom_type, identifier,
        abstract, title, authid, keywords, dates, spatial_extent,
        feature_count, field_names.

    Returns
    -------
    dict mapping feature name → float value
    """
    abstract  = layer_data.get("abstract",  "") or ""
    title     = layer_data.get("title",     "") or ""
    authid    = layer_data.get("authid",    "") or ""
    keywords  = layer_data.get("keywords",  []) or []
    extent    = layer_data.get("spatial_extent", {})
    dates     = layer_data.get("dates",     {})

    # Bounding box
    xmin = float(extent.get("xmin", 0.0))
    xmax = float(extent.get("xmax", 0.0))
    ymin = float(extent.get("ymin", 0.0))
    ymax = float(extent.get("ymax", 0.0))

    bbox_width  = xmax - xmin
    bbox_height = ymax - ymin
    bbox_area   = bbox_width * bbox_height

    # Date
    date_year  = 0.0
    date_month = 0.0
    created    = dates.get("Created", "")
    if created and len(created) >= 7:
        try:
            date_year  = float(created[:4])
            date_month = float(created[5:7])
        except ValueError:
            pass

    return {
        "abstract_len":           float(len(abstract)),
        "abstract_word_count":    float(len(abstract.split())) if abstract else 0.0,
        "abstract_entropy":       _vocab_entropy(abstract),
        "title_len":              float(len(title)),
        "title_word_count":       float(len(title.split())) if title else 0.0,
        "title_abstract_overlap": _title_abstract_overlap(title, abstract),
        "bbox_west":              xmin,
        "bbox_east":              xmax,
        "bbox_south":             ymin,
        "bbox_north":             ymax,
        "bbox_width":             bbox_width,
        "bbox_height":            bbox_height,
        "bbox_area":              bbox_area,
        "bbox_center_lat":        (ymin + ymax) / 2.0,
        "bbox_center_lon":        (xmin + xmax) / 2.0,
        "date_year":              date_year,
        "date_month":             date_month,
        "crs_encoded":            _encode_crs(authid),
        "keyword_count":          float(len(keywords)),
    }


def _normalise_score(raw, score_min, score_max):
    """
    Normalise a raw model score to 0.0–1.0 where 1.0 = most anomalous.
    Isolation Forest scores are negative; lower = more anomalous.
    We invert so that higher output = more suspicious.
    """
    if score_max == score_min:
        return 0.5
    # Clamp to known training range
    raw    = max(score_min, min(score_max, raw))
    normed = (raw - score_min) / (score_max - score_min)
    return round(1.0 - normed, 4)   # invert: low score → high probability


# ---------------------------------------------------------------------------
# PUBLIC API
# ---------------------------------------------------------------------------

def run_ml_detection(layer_data: dict) -> dict:
    """
    Run the pre-trained ML anomaly detection models on a QGIS layer.

    Parameters
    ----------
    layer_data : dict
        Output of semantic_checker._extract_from_layer(layer).
        Passed directly from the dialog so features are extracted once.

    Returns
    -------
    dict with keys:
        verdict         : "CLEAN" | "SUSPICIOUS" | "UNCERTAIN"
        tamper_prob     : float 0.0–1.0  (ensemble tamper probability)
        if_prob         : float 0.0–1.0  (Isolation Forest contribution)
        ocsvm_prob      : float 0.0–1.0  (One-Class SVM contribution)
        if_flagged      : bool
        ocsvm_flagged   : bool
        features        : dict of 19 extracted feature values
        feature_cols    : list of feature names in model order
        summary         : str  human-readable one-liner
        details         : str  multi-line breakdown for log
        error           : str or None
    """
    try:
        bundle = _load_bundle()
    except Exception as e:
        return _error_result(str(e))

    try:
        features     = _extract_features(layer_data)
        feature_cols = bundle["feature_cols"]

        # Build feature vector in exact training order
        X = [[features[col] for col in feature_cols]]

        # Scale using the SAME scaler fitted on training data
        import numpy as np
        X_scaled = bundle["scaler"].transform(X)

        # ── Isolation Forest ──────────────────────────────────────────────
        if_score   = float(bundle["iso_forest"].score_samples(X_scaled)[0])
        if_pred    = int(bundle["iso_forest"].predict(X_scaled)[0])
        if_flagged = (if_pred == -1)
        if_prob    = _normalise_score(
            if_score,
            bundle["if_score_min"],
            bundle["if_score_max"]
        )

        # ── One-Class SVM ─────────────────────────────────────────────────
        ocsvm_score   = float(bundle["ocsvm"].score_samples(X_scaled)[0])
        ocsvm_pred    = int(bundle["ocsvm"].predict(X_scaled)[0])
        ocsvm_flagged = (ocsvm_pred == -1)
        ocsvm_prob    = _normalise_score(
            ocsvm_score,
            bundle["ocsvm_score_min"],
            bundle["ocsvm_score_max"]
        )

        # ── Ensemble probability ──────────────────────────────────────────
        # Weighted average: OCSVM scored higher F1 (0.821) in validation
        tamper_prob = round(0.35 * if_prob + 0.65 * ocsvm_prob, 4)

        # ── Three-tier verdict ────────────────────────────────────────────
        if tamper_prob < 0.35:
            verdict = "CLEAN"
        elif tamper_prob < 0.60:
            verdict = "UNCERTAIN"
        else:
            verdict = "SUSPICIOUS"

        # ── Summary ───────────────────────────────────────────────────────
        flag_count = int(if_flagged) + int(ocsvm_flagged)
        summary = (
            f"ML verdict: {verdict}  |  "
            f"Tamper probability: {tamper_prob*100:.1f}%  |  "
            f"{flag_count}/2 models flagged"
        )

        # ── Detailed breakdown ────────────────────────────────────────────
        lines = [
            "═" * 58,
            "ML ANOMALY DETECTION  (Pillar 3)",
            f"Training data  : {bundle['training_source']}",
            f"Training size  : {bundle['train_size']} clean records",
            "─" * 58,
            "FEATURE VALUES (19 GIS-specific features):",
        ]
        for col in feature_cols:
            lines.append(f"  {col:30s}: {features[col]:.4f}")
        lines += [
            "─" * 58,
            "MODEL SCORES:",
            f"  Isolation Forest  : raw score {if_score:.4f}  "
            f"→ tamper prob {if_prob*100:.1f}%  "
            f"({'FLAGGED ✗' if if_flagged else 'CLEAN ✓'})",
            f"  One-Class SVM     : raw score {ocsvm_score:.4f}  "
            f"→ tamper prob {ocsvm_prob*100:.1f}%  "
            f"({'FLAGGED ✗' if ocsvm_flagged else 'CLEAN ✓'})",
            "─" * 58,
            f"  Ensemble probability (0.35×IF + 0.65×OCSVM): "
            f"{tamper_prob*100:.1f}%",
            f"  Verdict : {verdict}",
            "  Thresholds: CLEAN <35% | UNCERTAIN 35-60% | SUSPICIOUS >60%",
            "═" * 58,
        ]

        return {
            "verdict":      verdict,
            "tamper_prob":  tamper_prob,
            "if_prob":      if_prob,
            "ocsvm_prob":   ocsvm_prob,
            "if_flagged":   if_flagged,
            "ocsvm_flagged":ocsvm_flagged,
            "features":     features,
            "feature_cols": feature_cols,
            "summary":      summary,
            "details":      "\n".join(lines),
            "error":        None,
        }

    except Exception as e:
        return _error_result(str(e))


def _error_result(msg):
    return {
        "verdict":      "ERROR",
        "tamper_prob":  0.0,
        "if_prob":      0.0,
        "ocsvm_prob":   0.0,
        "if_flagged":   False,
        "ocsvm_flagged":False,
        "features":     {},
        "feature_cols": [],
        "summary":      f"ML detection error: {msg}",
        "details":      f"ML detection error: {msg}",
        "error":        msg,
    }
